package fploy.bai4;

import static org.junit.Assert.*;
import org.junit.*;
import org.junit.rules.ExpectedException;

/**
 * Test Cases cho form Add Organization Unit
 * 
 * KỊCH BẢN KIỂM THỬ:
 * TC01: Thêm Organization Unit thành công với đầy đủ thông tin
 * TC02: Thêm Organization Unit chỉ với Name (không có UnitId và Description)
 * TC03: Thêm thất bại khi Name rỗng
 * TC04: Thêm thất bại khi Name null
 * TC05: Kiểm tra trùng lặp UnitId
 * TC06: Kiểm tra Name chỉ chứa khoảng trắng
 */
public class OrganizationTest {

    private OrganizationDAO dao;

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @Before
    public void setUp() throws Exception {
        dao = new OrganizationDAO();
        dao.deleteAll(); // Clean database before each test
    }

    @After
    public void tearDown() throws Exception {
        if (dao != null) {
            dao.deleteAll();
            dao.close();
        }
    }

    // TC01: Thêm Organization Unit thành công với đầy đủ thông tin
    @Test
    public void testSaveWithAllFields_Success() throws Exception {
        OrganizationUnit unit = new OrganizationUnit("ORG001", "IT Department", "Information Technology");

        boolean result = dao.save(unit);

        assertTrue("Save should return true", result);

        OrganizationUnit saved = dao.findById("ORG001");
        assertNotNull("Saved unit should be found", saved);
        assertEquals("IT Department", saved.getName());
        assertEquals("Information Technology", saved.getDescription());

        System.out.println("TC01 PASSED: Thêm Organization Unit thành công");
    }

    // TC02: Thêm Organization Unit chỉ với Name (UnitId và Description có thể null)
    @Test
    public void testSaveWithOnlyName_Success() throws Exception {
        OrganizationUnit unit = new OrganizationUnit(null, "HR Department", null);

        boolean result = dao.save(unit);

        assertTrue("Save should return true", result);
        System.out.println("TC02 PASSED: Thêm Organization Unit chỉ với Name thành công");
    }

    // TC03: Thêm thất bại khi Name rỗng
    @Test(expected = IllegalArgumentException.class)
    public void testSaveWithEmptyName_Fail() throws Exception {
        OrganizationUnit unit = new OrganizationUnit("ORG002", "", "Test Description");

        dao.save(unit); // Should throw IllegalArgumentException

        System.out.println("TC03 PASSED: Name rỗng gây ra lỗi");
    }

    // TC04: Thêm thất bại khi Name null
    @Test
    public void testSaveWithNullName_Fail() throws Exception {
        exception.expect(IllegalArgumentException.class);
        exception.expectMessage("Name is required!");

        OrganizationUnit unit = new OrganizationUnit("ORG003", null, "Test Description");
        dao.save(unit);

        System.out.println("TC04 PASSED: Name null gây ra lỗi");
    }

    // TC05: Kiểm tra trùng lặp UnitId
    @Test
    public void testSaveDuplicateUnitId_Fail() throws Exception {
        OrganizationUnit unit1 = new OrganizationUnit("ORG004", "Department A", "Desc A");
        OrganizationUnit unit2 = new OrganizationUnit("ORG004", "Department B", "Desc B");

        dao.save(unit1);

        try {
            dao.save(unit2); // Should fail due to duplicate primary key
            fail("Should have thrown SQLException for duplicate UnitId");
        } catch (Exception e) {
            System.out.println("TC05 PASSED: Trùng lặp UnitId gây ra lỗi - " + e.getMessage());
        }
    }

    // TC06: Kiểm tra Name chỉ chứa khoảng trắng
    @Test(expected = IllegalArgumentException.class)
    public void testSaveWithWhitespaceName_Fail() throws Exception {
        OrganizationUnit unit = new OrganizationUnit("ORG005", "   ", "Test Description");

        dao.save(unit); // Should throw IllegalArgumentException

        System.out.println("TC06 PASSED: Name chỉ chứa khoảng trắng gây ra lỗi");
    }
}
