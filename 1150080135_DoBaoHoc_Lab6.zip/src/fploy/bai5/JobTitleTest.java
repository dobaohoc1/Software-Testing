package fploy.bai5;

import org.junit.Test;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import static org.junit.Assert.*;

public class JobTitleTest {

    // Helper to generate string of specific length
    private String generateString(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append("a");
        }
        return sb.toString();
    }

    // Helper to create dummy file of specific size in KB
    private String createDummyFile(String filename, int sizeInKB) throws IOException {
        File file = new File(filename);
        try (FileOutputStream fos = new FileOutputStream(file)) {
            byte[] buffer = new byte[1024];
            for (int i = 0; i < sizeInKB; i++) {
                fos.write(buffer);
            }
            // For exact byte size (if needed), but loop does KB.
            // Handle if sizeInKB is 0
            if (sizeInKB == 0) {
                // write nothing
            }
        }
        return file.getAbsolutePath();
    }

    // Helper to delete file
    private void deleteFile(String path) {
        if (path != null) {
            new File(path).delete();
        }
    }

    // --- JOB TITLE PARTITIONS ---

    // Partition 1: Job Title Empty (Fail)
    @Test(expected = IllegalArgumentException.class)
    public void testJobTitleEmpty() {
        JobTitle job = new JobTitle("", "Desc", null, null);
        job.validate();
    }

    // Partition 2: Job Title Valid (1-100 chars) (Pass)
    @Test
    public void testJobTitleValid() {
        String validTitle = generateString(100);
        JobTitle job = new JobTitle(validTitle, "Desc", null, null);
        job.validate(); // Should pass
    }

    // Partition 3: Job Title Too Long (> 100 chars) (Fail)
    @Test(expected = IllegalArgumentException.class)
    public void testJobTitleTooLong() {
        String invalidTitle = generateString(101);
        JobTitle job = new JobTitle(invalidTitle, "Desc", null, null);
        job.validate();
    }

    // --- DESCRIPTION PARTITIONS ---

    // Partition 4: Description Empty (Pass)
    @Test
    public void testDescriptionEmpty() {
        JobTitle job = new JobTitle("Title", "", null, null);
        job.validate();
    }

    // Partition 5: Description Valid (1-400 chars) (Pass)
    @Test
    public void testDescriptionValid() {
        String validDesc = generateString(400);
        JobTitle job = new JobTitle("Title", validDesc, null, null);
        job.validate();
    }

    // Partition 6: Description Too Long (> 400 chars) (Fail)
    @Test(expected = IllegalArgumentException.class)
    public void testDescriptionTooLong() {
        String invalidDesc = generateString(401);
        JobTitle job = new JobTitle("Title", invalidDesc, null, null);
        job.validate();
    }

    // --- JOB SPECIFICATION (FILE) PARTITIONS ---

    // Partition 7: File Empty (0KB) (Pass)
    @Test
    public void testFileEmpty() throws IOException {
        String path = createDummyFile("empty.txt", 0);
        try {
            JobTitle job = new JobTitle("Title", "Desc", path, null);
            job.validate();
        } finally {
            deleteFile(path);
        }
    }

    // Partition 8: File Valid (<= 1024KB) (Pass) - Testing boundary 1024KB
    @Test
    public void testFileValid() throws IOException {
        String path = createDummyFile("valid.txt", 1024); // 1MB
        try {
            JobTitle job = new JobTitle("Title", "Desc", path, null);
            job.validate();
        } finally {
            deleteFile(path);
        }
    }

    // Partition 9: File Too Large (> 1024KB) (Fail)
    @Test(expected = IllegalArgumentException.class)
    public void testFileTooLarge() throws IOException {
        String path = createDummyFile("large.txt", 1025); // 1MB + 1KB
        try {
            JobTitle job = new JobTitle("Title", "Desc", path, null);
            job.validate();
        } finally {
            deleteFile(path);
        }
    }

    // --- NOTE PARTITIONS ---

    // Partition 10: Note Empty (Pass)
    @Test
    public void testNoteEmpty() {
        JobTitle job = new JobTitle("Title", "Desc", null, "");
        job.validate();
    }

    // Partition 11: Note Valid (1-400 chars) (Pass)
    @Test
    public void testNoteValid() {
        String validNote = generateString(400);
        JobTitle job = new JobTitle("Title", "Desc", null, validNote);
        job.validate();
    }

    // Partition 12: Note Too Long (> 400 chars) (Fail)
    @Test(expected = IllegalArgumentException.class)
    public void testNoteTooLong() {
        String invalidNote = generateString(401);
        JobTitle job = new JobTitle("Title", "Desc", null, invalidNote);
        job.validate();
    }
}
