package fploy.bai6;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class UserForm extends JFrame {

    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JTextField txtFullname;
    private JTextField txtEmail;
    private UserDAO dao;

    public UserForm() {
        try {
            dao = new UserDAO();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage(), "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

        setTitle("NGHIENPHIM - User Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 500);

        // Sidebar and Main Content Layout
        JPanel container = new JPanel(new BorderLayout());
        setContentPane(container);

        // Sidebar (Mockup)
        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(30, 35, 60)); // Dark Blue
        sidebar.setPreferredSize(new Dimension(200, 500));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));

        addSidebarItem("Management", sidebar, true);
        addSidebarItem("Home", sidebar, false);
        addSidebarItem("Video Management", sidebar, false);
        addSidebarItem("User Management", sidebar, false); // Active mock
        addSidebarItem("Report Management", sidebar, false);
        addSidebarItem("Logout", sidebar, false);

        container.add(sidebar, BorderLayout.WEST);

        // Main Content Area
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(25, 30, 50)); // Darker Blue
        container.add(mainPanel, BorderLayout.CENTER);

        // Header (Mockup)
        JPanel header = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        header.setBackground(new Color(25, 30, 50));
        JLabel lblUser = new JLabel("Thay Huynh");
        lblUser.setForeground(Color.WHITE);
        header.add(lblUser);
        mainPanel.add(header, BorderLayout.NORTH);

        // Tabs
        JTabbedPane tabbedPane = new JTabbedPane();
        JPanel editionPanel = createEditionPanel();
        JPanel listPanel = new JPanel(); // Placeholder for List
        listPanel.setBackground(new Color(35, 40, 65));

        tabbedPane.addTab("USER EDITION", editionPanel);
        tabbedPane.addTab("USER LIST", listPanel);

        // Style Tabbed Pane roughly
        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        // Close DB
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                try {
                    if (dao != null)
                        dao.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    private void addSidebarItem(String text, JPanel sidebar, boolean isTitle) {
        JLabel label = new JLabel(text);
        label.setForeground(isTitle ? Color.GRAY : Color.LIGHT_GRAY);
        label.setFont(new Font("SansSerif", isTitle ? Font.BOLD : Font.PLAIN, 14));
        label.setBorder(new EmptyBorder(10, 20, 10, 20));
        sidebar.add(label);
    }

    private JPanel createEditionPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBackground(new Color(35, 40, 65)); // Panel bg
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username
        JLabel lblUsername = new JLabel("Username");
        lblUsername.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(lblUsername, gbc);

        txtUsername = new JTextField(20);
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(txtUsername, gbc);

        // Password
        JLabel lblPassword = new JLabel("Password");
        lblPassword.setForeground(Color.WHITE);
        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(lblPassword, gbc);

        txtPassword = new JPasswordField(20);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(txtPassword, gbc);

        // Fullname
        JLabel lblFullname = new JLabel("Fullname");
        lblFullname.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(lblFullname, gbc);

        txtFullname = new JTextField(20);
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(txtFullname, gbc);

        // Email
        JLabel lblEmail = new JLabel("Email");
        lblEmail.setForeground(Color.WHITE);
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(lblEmail, gbc);

        txtEmail = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(txtEmail, gbc);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnPanel.setOpaque(false);

        JButton btnCreate = new JButton("Create");
        styleButton(btnCreate, new Color(50, 100, 200));
        btnCreate.addActionListener(e -> createAction());

        JButton btnUpdate = new JButton("Update");
        styleButton(btnUpdate, new Color(50, 200, 100));
        btnUpdate.addActionListener(e -> updateAction());

        JButton btnDelete = new JButton("Delete");
        styleButton(btnDelete, new Color(200, 50, 100));
        btnDelete.addActionListener(e -> deleteAction());

        JButton btnReset = new JButton("Reset");
        styleButton(btnReset, new Color(200, 150, 50));
        btnReset.addActionListener(e -> resetAction());

        btnPanel.add(btnCreate);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnReset);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2; // Span across columns
        panel.add(btnPanel, gbc);

        // Spacer to push everything up
        gbc.gridy = 5;
        gbc.weighty = 1.0;
        panel.add(new JLabel(), gbc);

        return panel;
    }

    private void styleButton(JButton btn, Color bg) {
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
    }

    // Actions
    private void createAction() {
        try {
            User user = new User(txtUsername.getText(), new String(txtPassword.getPassword()), txtFullname.getText(),
                    txtEmail.getText());
            if (dao.insert(user)) {
                JOptionPane.showMessageDialog(this, "User created successfully!");
                resetAction();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to create user.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void updateAction() {
        try {
            User user = new User(txtUsername.getText(), new String(txtPassword.getPassword()), txtFullname.getText(),
                    txtEmail.getText());
            if (dao.update(user)) {
                JOptionPane.showMessageDialog(this, "User updated successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Username not found to update.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void deleteAction() {
        try {
            if (dao.delete(txtUsername.getText())) {
                JOptionPane.showMessageDialog(this, "User deleted successfully!");
                resetAction();
            } else {
                JOptionPane.showMessageDialog(this, "Username not found to delete.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void resetAction() {
        txtUsername.setText("");
        txtPassword.setText("");
        txtFullname.setText("");
        txtEmail.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
            }
            new UserForm().setVisible(true);
        });
    }
}
