package dtm.bai2_1;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

/**
 * BAI 2.1 - CheckoutTest
 * Nhom: smoke (testCheckoutNavigation)
 * regression (tat ca)
 */
public class CheckoutTest {

    private WebDriver driver;
    private WebDriverWait wait;

    private static final By USERNAME_INPUT = By.id("user-name");
    private static final By PASSWORD_INPUT = By.id("password");
    private static final By LOGIN_BUTTON = By.id("login-button");
    private static final By ADD_TO_CART_BTN = By.id("add-to-cart-sauce-labs-backpack");
    private static final By CART_ICON = By.className("shopping_cart_link");
    private static final By CHECKOUT_BTN = By.id("checkout");
    private static final By FIRST_NAME_INPUT = By.id("first-name");
    private static final By LAST_NAME_INPUT = By.id("last-name");
    private static final By POSTAL_INPUT = By.id("postal-code");
    private static final By CONTINUE_BTN = By.id("continue");
    private static final By FINISH_BTN = By.id("finish");
    private static final By ERROR_MESSAGE = By.cssSelector("[data-test='error']");

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        // Dang nhap va them san pham vao gio hang
        driver.get("https://www.saucedemo.com");
        wait.until(ExpectedConditions.visibilityOfElementLocated(USERNAME_INPUT))
                .sendKeys("standard_user");
        driver.findElement(PASSWORD_INPUT).sendKeys("secret_sauce");
        driver.findElement(LOGIN_BUTTON).click();
        wait.until(ExpectedConditions.urlContains("inventory.html"));
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (driver != null)
            driver.quit();
    }

    // SMOKE + REGRESSION: Di chuyen den trang checkout
    @Test(groups = { "smoke", "regression" }, description = "TC_CH1 - Di chuyen den trang Checkout thanh cong")
    public void testCheckoutNavigation() {
        // Them san pham
        wait.until(ExpectedConditions.elementToBeClickable(ADD_TO_CART_BTN)).click();
        // Vao gio hang
        driver.findElement(CART_ICON).click();
        wait.until(ExpectedConditions.urlContains("cart.html"));
        // Click Checkout
        wait.until(ExpectedConditions.elementToBeClickable(CHECKOUT_BTN)).click();
        wait.until(ExpectedConditions.urlContains("checkout-step-one.html"));
        Assert.assertTrue(driver.getCurrentUrl().contains("checkout-step-one.html"),
                "TC_CH1 FAILED: Khong chuyen sang trang checkout-step-one");
    }

    // REGRESSION: Form thong tin trong → hien loi
    @Test(groups = { "regression" }, description = "TC_CH2 - Checkout khi de trong form thong tin")
    public void testCheckoutEmptyForm() {
        // Them san pham va vao checkout
        wait.until(ExpectedConditions.elementToBeClickable(ADD_TO_CART_BTN)).click();
        driver.findElement(CART_ICON).click();
        wait.until(ExpectedConditions.elementToBeClickable(CHECKOUT_BTN)).click();
        wait.until(ExpectedConditions.urlContains("checkout-step-one.html"));
        // Nhan Continue khi de trong form
        wait.until(ExpectedConditions.elementToBeClickable(CONTINUE_BTN)).click();
        WebElement err = wait.until(ExpectedConditions.visibilityOfElementLocated(ERROR_MESSAGE));
        Assert.assertTrue(err.getText().contains("First Name is required"),
                "TC_CH2 FAILED: Phai hien loi 'First Name is required'. Actual: " + err.getText());
    }

    // REGRESSION: Checkout hoan chinh tu dau den cuoi
    @Test(groups = { "regression" }, description = "TC_CH3 - Checkout hoan chinh den trang Complete")
    public void testCheckoutComplete() {
        // Them san pham
        wait.until(ExpectedConditions.elementToBeClickable(ADD_TO_CART_BTN)).click();
        // Vao gio hang → Checkout
        driver.findElement(CART_ICON).click();
        wait.until(ExpectedConditions.elementToBeClickable(CHECKOUT_BTN)).click();
        wait.until(ExpectedConditions.urlContains("checkout-step-one.html"));
        // Dien thong tin
        wait.until(ExpectedConditions.visibilityOfElementLocated(FIRST_NAME_INPUT))
                .sendKeys("Nguyen");
        driver.findElement(LAST_NAME_INPUT).sendKeys("Van A");
        driver.findElement(POSTAL_INPUT).sendKeys("700000");
        driver.findElement(CONTINUE_BTN).click();
        // Overview → Finish
        wait.until(ExpectedConditions.urlContains("checkout-step-two.html"));
        wait.until(ExpectedConditions.elementToBeClickable(FINISH_BTN)).click();
        // Kiem tra hoan thanh
        wait.until(ExpectedConditions.urlContains("checkout-complete.html"));
        Assert.assertTrue(driver.getCurrentUrl().contains("checkout-complete.html"),
                "TC_CH3 FAILED: Khong chuyen sang trang checkout-complete");
    }
}
