package dtm.bai2_1;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

/**
 * BAI 2.1 - LoginTest
 * Nhom: smoke (testLoginSuccess)
 * regression (tat ca)
 */
public class LoginTest {

    private WebDriver driver;
    private WebDriverWait wait;

    private static final By USERNAME_INPUT = By.id("user-name");
    private static final By PASSWORD_INPUT = By.id("password");
    private static final By LOGIN_BUTTON = By.id("login-button");
    private static final By ERROR_MESSAGE = By.cssSelector("[data-test='error']");

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get("https://www.saucedemo.com");
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (driver != null)
            driver.quit();
    }

    // SMOKE + REGRESSION: Dang nhap hop le
    @Test(groups = { "smoke", "regression" }, description = "TC_L1 - Dang nhap voi user/pass hop le")
    public void testLoginSuccess() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(USERNAME_INPUT))
                .sendKeys("standard_user");
        driver.findElement(PASSWORD_INPUT).sendKeys("secret_sauce");
        driver.findElement(LOGIN_BUTTON).click();
        wait.until(ExpectedConditions.urlContains("inventory.html"));
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory.html"),
                "TC_L1 FAILED: Khong chuyen sang inventory.html");
    }

    // REGRESSION: Dang nhap sai mat khau
    @Test(groups = { "regression" }, description = "TC_L2 - Dang nhap voi mat khau sai")
    public void testLoginFail() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(USERNAME_INPUT))
                .sendKeys("standard_user");
        driver.findElement(PASSWORD_INPUT).sendKeys("wrong_pass");
        driver.findElement(LOGIN_BUTTON).click();
        WebElement err = wait.until(ExpectedConditions.visibilityOfElementLocated(ERROR_MESSAGE));
        Assert.assertTrue(err.getText().contains("Username and password do not match"),
                "TC_L2 FAILED: Thong bao loi sai. Actual: " + err.getText());
    }

    // REGRESSION: De trong ca username va password
    @Test(groups = { "regression" }, description = "TC_L3 - De trong ca username va password")
    public void testLoginEmpty() {
        driver.findElement(LOGIN_BUTTON).click();
        WebElement err = wait.until(ExpectedConditions.visibilityOfElementLocated(ERROR_MESSAGE));
        Assert.assertTrue(err.getText().contains("Username is required"),
                "TC_L3 FAILED: Actual: " + err.getText());
    }
}
