package dtm.bai3_1;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * BAI 3.1 - Thiet ke test case dat 100% Branch Coverage cho ham xepLoai()
 */
public class XepLoaiTest {

    // TC1: diemTB = -1 (< 0) -> Diem khong hop le
    @Test(description = "TC1: Kiem tra diem khong hop le (nho hon 0)")
    public void testDiemKhongHopLeAm() {
        Assert.assertEquals(StudentUtils.xepLoai(-1.0, false), "Diem khong hop le");
    }

    // Tcb: diemTB = 11 (> 10) -> Diem khong hop le
    @Test(description = "TC2: Kiem tra diem khong hop le (lon hon 10)")
    public void testDiemKhongHopLeVuot() {
        Assert.assertEquals(StudentUtils.xepLoai(11.0, false), "Diem khong hop le");
    }

    // TC3: diemTB = 9.0 (>= 8.5) -> Gioi
    @Test(description = "TC3: Kiem tra diem Gioi")
    public void testDiemGioi() {
        Assert.assertEquals(StudentUtils.xepLoai(9.0, false), "Gioi");
    }

    // TC4: diemTB = 7.5 (>= 7.0) -> Kha
    @Test(description = "TC4: Kiem tra diem Kha")
    public void testDiemKha() {
        Assert.assertEquals(StudentUtils.xepLoai(7.5, false), "Kha");
    }

    // TC5: diemTB = 6.0 (>= 5.5) -> Trung Binh
    @Test(description = "TC5: Kiem tra diem Trung Binh")
    public void testDiemTrungBinh() {
        Assert.assertEquals(StudentUtils.xepLoai(6.0, false), "Trung Binh");
    }

    // TC6: diemTB = 4.0, coThiLai = true -> Thi lai
    @Test(description = "TC6: Kiem tra co thi lai")
    public void testThiLai() {
        Assert.assertEquals(StudentUtils.xepLoai(4.0, true), "Thi lai");
    }

    // TC7: diemTB = 4.0, coThiLai = false -> Yeu - Hoc lai
    @Test(description = "TC7: Kiem tra Yeu - Hoc lai (khong thi lai)")
    public void testHocLai() {
        Assert.assertEquals(StudentUtils.xepLoai(4.0, false), "Yeu - Hoc lai");
    }
}
