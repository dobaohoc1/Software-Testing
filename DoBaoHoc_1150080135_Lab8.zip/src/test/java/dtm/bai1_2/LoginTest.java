package dtm.bai1_2;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

/**
 * BAI 1.2 - KIEM THU FORM DANG NHAP (saucedemo.com)
 *
 * Ky thuat: Selenium WebDriver + TestNG + Explicit Wait (WebDriverWait)
 * Website : https://www.saucedemo.com
 *
 * TC_B12_001 - Dang nhap hop le → chuyen sang /inventory.html
 * TC_B12_002 - Sai mat khau → thong bao loi xuat hien
 * TC_B12_003 - Bo trong username → "Username is required"
 * TC_B12_004 - Bo trong password → "Password is required"
 * TC_B12_005 - locked_out_user → "Sorry, this user has been locked out"
 */
public class LoginTest {

    private WebDriver driver;
    private WebDriverWait wait;

    // Locators
    private static final By USERNAME_INPUT = By.id("user-name");
    private static final By PASSWORD_INPUT = By.id("password");
    private static final By LOGIN_BUTTON = By.id("login-button");
    private static final By ERROR_MESSAGE = By.cssSelector("[data-test='error']");

    // Test data
    private static final String BASE_URL = "https://www.saucedemo.com";
    private static final String VALID_USER = "standard_user";
    private static final String VALID_PASS = "secret_sauce";
    private static final String LOCKED_USER = "locked_out_user";
    private static final String WRONG_PASS = "wrong_password_123";

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");
        driver = new ChromeDriver(options);
        // Su dung Explicit Wait thay vi Thread.sleep()
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get(BASE_URL);
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    // TC_B12_001 - Dang nhap hop le
    @Test(description = "TC_B12_001 - Dang nhap voi user/pass hop le")
    public void testLoginSuccess() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(USERNAME_INPUT))
                .sendKeys(VALID_USER);
        driver.findElement(PASSWORD_INPUT).sendKeys(VALID_PASS);
        driver.findElement(LOGIN_BUTTON).click();
        wait.until(ExpectedConditions.urlContains("inventory.html"));
        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue(currentUrl.contains("inventory.html"),
                "TC_B12_001 FAILED: URL phai chua 'inventory.html'. Actual: " + currentUrl);
    }

    // TC_B12_002 - Sai mat khau
    @Test(description = "TC_B12_002 - Dang nhap voi mat khau sai")
    public void testLoginWrongPassword() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(USERNAME_INPUT))
                .sendKeys(VALID_USER);
        driver.findElement(PASSWORD_INPUT).sendKeys(WRONG_PASS);
        driver.findElement(LOGIN_BUTTON).click();
        WebElement err = wait.until(ExpectedConditions.visibilityOfElementLocated(ERROR_MESSAGE));
        Assert.assertTrue(err.isDisplayed(),
                "TC_B12_002 FAILED: Thong bao loi khong xuat hien");
        Assert.assertTrue(err.getText().contains("Username and password do not match"),
                "TC_B12_002 FAILED: Noi dung thong bao sai. Actual: [" + err.getText() + "]");
    }

    // TC_B12_003 - Bo trong username
    @Test(description = "TC_B12_003 - Dang nhap khi de trong Username")
    public void testLoginEmptyUsername() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(PASSWORD_INPUT))
                .sendKeys(VALID_PASS);
        driver.findElement(LOGIN_BUTTON).click();
        WebElement err = wait.until(ExpectedConditions.visibilityOfElementLocated(ERROR_MESSAGE));
        Assert.assertTrue(err.getText().contains("Username is required"),
                "TC_B12_003 FAILED: Phai la 'Username is required'. Actual: [" + err.getText() + "]");
    }

    // TC_B12_004 - Bo trong password
    @Test(description = "TC_B12_004 - Dang nhap khi de trong Password")
    public void testLoginEmptyPassword() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(USERNAME_INPUT))
                .sendKeys(VALID_USER);
        driver.findElement(LOGIN_BUTTON).click();
        WebElement err = wait.until(ExpectedConditions.visibilityOfElementLocated(ERROR_MESSAGE));
        Assert.assertTrue(err.getText().contains("Password is required"),
                "TC_B12_004 FAILED: Phai la 'Password is required'. Actual: [" + err.getText() + "]");
    }

    // TC_B12_005 - Tai khoan bi khoa
    @Test(description = "TC_B12_005 - Dang nhap bang tai khoan bi khoa (locked_out_user)")
    public void testLoginLockedUser() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(USERNAME_INPUT))
                .sendKeys(LOCKED_USER);
        driver.findElement(PASSWORD_INPUT).sendKeys(VALID_PASS);
        driver.findElement(LOGIN_BUTTON).click();
        WebElement err = wait.until(ExpectedConditions.visibilityOfElementLocated(ERROR_MESSAGE));
        Assert.assertTrue(err.getText().contains("Sorry, this user has been locked out"),
                "TC_B12_005 FAILED: Phai chua 'locked out'. Actual: [" + err.getText() + "]");
    }
}
