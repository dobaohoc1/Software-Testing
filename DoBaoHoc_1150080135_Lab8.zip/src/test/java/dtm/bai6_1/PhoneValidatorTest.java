package dtm.bai6_1;

import org.testng.Assert;
import org.testng.annotations.Test;

public class PhoneValidatorTest {

    @Test(description = "Mục tiêu: Báo null rỗng -> false")
    public void testSDT_NullHoacRong() {
        Assert.assertFalse(PhoneValidator.isValid(""));
        Assert.assertFalse(PhoneValidator.isValid(null));
        Assert.assertFalse(PhoneValidator.isValid("   "));
    }

    @Test(description = "Mục tiêu: Chứa ký tự không hợp lệ (chữ cái, ký tự đặc biệt) -> false")
    public void testSDT_KyTuRac() {
        Assert.assertFalse(PhoneValidator.isValid("090ABC1234"));
        Assert.assertFalse(PhoneValidator.isValid("090!@#1234"));
    }

    @Test(description = "Mục tiêu: Chuẩn hóa thành công đầu +84 -> hợp lệ true")
    public void testSDT_DauSoQuocTeCong84() {
        Assert.assertTrue(PhoneValidator.isValid("+84 90 123 4567"), "Phải được chấp nhận chuẩn hóa thành 0901234567");
        Assert.assertTrue(PhoneValidator.isValid("+84901234567")); // Viết liền
    }

    @Test(description = "Mục tiêu: Độ dài sai sau khi chuẩn hóa (Thiếu hoặc dư số) -> false")
    public void testSDT_SaiDoDai() {
        Assert.assertFalse(PhoneValidator.isValid("090 123")); // 6 số
        Assert.assertFalse(PhoneValidator.isValid("+84 90 123 4567 89")); // Dư số
    }

    @Test(description = "Mục tiêu: Đúng 10 số nhưng đầu số không cho phép (vd: 02, 06...) -> false")
    public void testSDT_SaiDauSo() {
        Assert.assertFalse(PhoneValidator.isValid("020 123 4567"));
        Assert.assertFalse(PhoneValidator.isValid("060 123 4567"));
    }

    @Test(description = "Mục tiêu: Số chuẩn, có dấu cách, đầu số đa dạng (03, 05, 07, 08, 09) -> true")
    public void testSDT_HoanToanHopLe() {
        Assert.assertTrue(PhoneValidator.isValid("030 123 4567"));
        Assert.assertTrue(PhoneValidator.isValid("050 123 4567"));
        Assert.assertTrue(PhoneValidator.isValid("070 123 4567"));
        Assert.assertTrue(PhoneValidator.isValid("080 123 4567"));
        Assert.assertTrue(PhoneValidator.isValid("090 123 4567")); // Chuẩn mực
    }
}
