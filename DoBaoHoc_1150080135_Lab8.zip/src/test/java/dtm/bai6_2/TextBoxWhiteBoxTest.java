package dtm.bai6_2;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class TextBoxWhiteBoxTest {

    private WebDriver driver;
    private TextBoxPage textBoxPage;

    @BeforeMethod
    public void setup() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless=new"); // Chạy nền tiết kiệm tài nguyên
        options.addArguments("--remote-allow-origins=*");

        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize(); // Tránh bị Layout responsive làm vỡ locator

        // Mở URL form Text Box
        driver.get("https://demoqa.com/text-box");
        textBoxPage = new TextBoxPage(driver);
    }

    /*
     * KIỂM THỬ TRƯỜNG HỢP BIÊN (BOUNDARY VALUE & EQUIVALENCE PARTITIONING TEST
     * CASES)
     */

    @Test(description = "TC1: Để trống toàn bộ Form (Empty Fields)")
    public void testForm_EmptyFields() {
        // Nhập khoảng trắng (rỗng)
        textBoxPage.fillAndSubmit("", "", "");

        // Output section sẽ không hiển thị thông tin nếu không có dữ liệu chèn vào
        Assert.assertFalse(textBoxPage.isOutputDisplayed(), "Lỗi: Output vẫn xuất hiện khi nhập rỗng!");
    }

    @Test(description = "TC2: Email sai định dạng (Thiếu dấu @)")
    public void testForm_InvalidEmail_NoAtSymbol() {
        // Nhập email rác thành chữ "helloadmin"
        textBoxPage.fillAndSubmit("Nguyen Van A", "helloadmin", "123 Street");

        // Trình duyệt/JS Validation sẽ bật cờ đỏ và ngăn chặn xuất bảng output
        Assert.assertTrue(textBoxPage.isEmailErrorDisplayed(), "Lỗi: Email sai định dạng nhưng không bắt lỗi đỏ viền");
        Assert.assertFalse(textBoxPage.isOutputDisplayed(), "Lỗi: Email sai định dạng nhưng Vẫn hiển thị Output info");
    }

    @Test(description = "TC3: Email sai định dạng (Có @ nhưng rỗng đuôi Domain)")
    public void testForm_InvalidEmail_MissingDomain() {
        // Nhập "admin@"
        textBoxPage.fillAndSubmit("Tran B", "admin@", "456 Avenue");

        Assert.assertTrue(textBoxPage.isEmailErrorDisplayed(), "Lỗi: Thiếu đuôi Domain nhưng không báo đỏ");
    }

    @Test(description = "TC4: Nhập chuẩn kịch bản Happy Path")
    public void testForm_HappyPath_ValidInputs() {
        // Form đầy đủ 3 yếu tố chuẩn chỉnh
        textBoxPage.fillAndSubmit("Le Van C", "admin@gmail.com", "789 Boulevard");

        // Output phải bật ra và không dính cảnh báo email đỏ
        Assert.assertTrue(textBoxPage.isOutputDisplayed(), "Lỗi: Dữ liệu hợp lệ nhưng không bung bảng Output!");
        Assert.assertFalse(textBoxPage.isEmailErrorDisplayed(), "Lỗi: Viền đỏ sai sót hiện ra trên dữ liệu đúng");
    }

    @AfterMethod
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
