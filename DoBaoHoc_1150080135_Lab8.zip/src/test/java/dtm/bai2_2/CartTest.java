package dtm.bai2_2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

/**
 * BAI 2.2 - CartTest su dung DriverFactory (ThreadLocal)
 * Chay song song voi LoginTest tren Thread rieng biet
 */
public class CartTest {

    private static final By USERNAME_INPUT = By.id("user-name");
    private static final By PASSWORD_INPUT = By.id("password");
    private static final By LOGIN_BUTTON = By.id("login-button");
    private static final By ADD_TO_CART_BTN = By.id("add-to-cart-sauce-labs-backpack");
    private static final By CART_BADGE = By.className("shopping_cart_badge");
    private static final By REMOVE_BTN = By.id("remove-sauce-labs-backpack");
    private static final String BASE_URL = "https://www.saucedemo.com";

    @BeforeClass(alwaysRun = true)
    public void setUp() {
        // Moi class chay tren 1 thread rieng -> initDriver 1 lan
        DriverFactory.initDriver("chrome");
        WebDriver driver = DriverFactory.getDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        // Dang nhap truoc
        driver.get(BASE_URL);
        wait.until(ExpectedConditions.visibilityOfElementLocated(USERNAME_INPUT))
                .sendKeys("standard_user");
        driver.findElement(PASSWORD_INPUT).sendKeys("secret_sauce");
        driver.findElement(LOGIN_BUTTON).click();
        wait.until(ExpectedConditions.urlContains("inventory.html"));
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        DriverFactory.quitDriver();
    }

    // Tra ve inventory page truoc moi TC
    private void goToInventory() {
        WebDriver driver = DriverFactory.getDriver();
        driver.get("https://www.saucedemo.com/inventory.html");
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.urlContains("inventory.html"));
    }

    // TC_BC1 - Them san pham vao gio hang
    @Test(description = "TC_BC1 - Them Backpack vao gio hang")
    public void testAddToCart() {
        goToInventory();
        WebDriver driver = DriverFactory.getDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(ADD_TO_CART_BTN)).click();
        String badge = wait.until(
                ExpectedConditions.visibilityOfElementLocated(CART_BADGE)).getText();
        Assert.assertEquals(badge, "1",
                "TC_BC1 FAILED: Badge phai = 1. Thread: " + Thread.currentThread().getName());
    }

    // TC_BC2 - Xoa san pham khoi gio hang
    @Test(description = "TC_BC2 - Xoa Backpack khoi gio hang", dependsOnMethods = "testAddToCart")
    public void testRemoveFromCart() {
        WebDriver driver = DriverFactory.getDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(REMOVE_BTN)).click();
        boolean badgeGone = wait.until(
                ExpectedConditions.invisibilityOfElementLocated(CART_BADGE));
        Assert.assertTrue(badgeGone,
                "TC_BC2 FAILED: Badge van con hien thi. Thread: " + Thread.currentThread().getName());
    }
}
