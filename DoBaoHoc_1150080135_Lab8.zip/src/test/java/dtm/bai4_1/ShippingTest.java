package dtm.bai4_1;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * BAI 4.1 - Thiet ke tap 8 Basis Path Test Cases
 */
public class ShippingTest {

    // DP1: noi_thanh, tL = 6, member = false -> 15000 + (1)*2000 = 17000
    @Test(description = "BP1: noi_thanh, >5kg, khong member")
    public void testBP1() {
        Assert.assertEquals(ShippingUtils.tinhPhiShip(6, "noi_thanh", false), 17000.0);
    }

    // DP2: tL = 0 -> Exception
    @Test(description = "BP2: Trong luong <= 0 (Ném exception)", expectedExceptions = IllegalArgumentException.class)
    public void testBP2() {
        ShippingUtils.tinhPhiShip(0, "noi_thanh", false);
    }

    // DP3: ngoai_thanh, tL = 4, member = false -> 25000 + (1)*3000 = 28000
    @Test(description = "BP3: ngoai_thanh, >3kg, khong member")
    public void testBP3() {
        Assert.assertEquals(ShippingUtils.tinhPhiShip(4, "ngoai_thanh", false), 28000.0);
    }

    // DP4: noi_thanh, tL = 3, member = false -> 15000 + 0 = 15000
    @Test(description = "BP4: noi_thanh, <=5kg, khong member")
    public void testBP4() {
        Assert.assertEquals(ShippingUtils.tinhPhiShip(3, "noi_thanh", false), 15000.0);
    }

    // DP5: tinh_khac, tL = 3, member = false -> 50000 + (1)*5000 = 55000
    @Test(description = "BP5: tinh_khac, >2kg, khong member")
    public void testBP5() {
        Assert.assertEquals(ShippingUtils.tinhPhiShip(3, "tinh_khac", false), 55000.0);
    }

    // DP6: ngoai_thanh, tL = 2, member = false -> 25000 + 0 = 25000
    @Test(description = "BP6: ngoai_thanh, <=3kg, khong member")
    public void testBP6() {
        Assert.assertEquals(ShippingUtils.tinhPhiShip(2, "ngoai_thanh", false), 25000.0);
    }

    // DP7: tinh_khac, tL = 1, member = false -> 50000 + 0 = 50000
    @Test(description = "BP7: tinh_khac, <=2kg, khong member")
    public void testBP7() {
        Assert.assertEquals(ShippingUtils.tinhPhiShip(1, "tinh_khac", false), 50000.0);
    }

    // DP8: noi_thanh, tL = 6, member = true -> 17000 * 0.9 = 15300
    @Test(description = "BP8: noi_thanh, >5kg, la member (giam 10%)")
    public void testBP8() {
        Assert.assertEquals(ShippingUtils.tinhPhiShip(6, "noi_thanh", true), 15300.0);
    }
}
