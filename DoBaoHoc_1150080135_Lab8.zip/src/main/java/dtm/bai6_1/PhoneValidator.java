package dtm.bai6_1;

public class PhoneValidator {

    /**
     * Ham kiem tra so dien thoai Viet Nam hop le.
     * TDD: Viet test -> Viet logic pass -> Do Coverage.
     */
    public static boolean isValid(String phone) {
        if (phone == null || phone.trim().isEmpty()) { // D1
            return false;
        }

        // Ràng buộc ký tự: Chỉ cho phép số, dấu + và khoảng trắng
        if (!phone.matches("^[0-9+ ]+$")) { // D2
            return false;
        }

        // Chuẩn hóa: Xóa khoảng trắng
        String norm = phone.replace(" ", "");

        // Chuẩn hóa: Nếu bắt đầu bằng +84 thì chuyển thành số 0
        if (norm.startsWith("+84")) { // D3
            norm = "0" + norm.substring(3);
        }

        // Độ dài bắt buộc phải là 10 số (chính xác)
        if (norm.length() != 10) { // D4
            return false;
        }

        // Đầu số hợp lệ: 03, 05, 07, 08, 09
        if (norm.matches("^0[35789][0-9]{8}$")) { // D5
            return true;
        }

        return false;
    }
}
