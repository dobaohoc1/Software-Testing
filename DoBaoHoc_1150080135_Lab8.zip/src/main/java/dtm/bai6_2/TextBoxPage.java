package dtm.bai6_2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TextBoxPage {
    private WebDriver driver;

    @FindBy(id = "userName")
    private WebElement nameField;

    @FindBy(id = "userEmail")
    private WebElement emailField;

    @FindBy(id = "currentAddress")
    private WebElement currentAddressField;

    @FindBy(id = "submit")
    private WebElement submitBtn;

    @FindBy(id = "output")
    private WebElement outputSection;

    // Element chứng minh email bị lỗi CSS red border do sai định dạng validation JS
    @FindBy(css = ".field-error")
    private WebElement emailErrorState;

    // Các thẻ con bên trong output khi submit thành công
    @FindBy(id = "name")
    private WebElement outputName;

    public TextBoxPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void fillAndSubmit(String name, String email, String address) {
        nameField.clear();
        if (name != null)
            nameField.sendKeys(name);

        emailField.clear();
        if (email != null)
            emailField.sendKeys(email);

        currentAddressField.clear();
        if (address != null)
            currentAddressField.sendKeys(address);

        // Scroll to submit button and click using Javascript để tránh bị quảng cáo che
        // mất
        org.openqa.selenium.JavascriptExecutor js = (org.openqa.selenium.JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", submitBtn);
        js.executeScript("arguments[0].click();", submitBtn);
    }

    public boolean isOutputDisplayed() {
        try {
            // Demoqa sẽ xuất hiện element con <p id="name"> bên trong #output nếu thành
            // công
            return outputName.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isEmailErrorDisplayed() {
        try {
            // Nếu email nhập sai đuôi, class CSS .field-error sẽ xuất hiện (khung viền đỏ)
            return emailErrorState.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
