package dtm.bai5_1;

public class BankLoanUtils {

    /**
     * Ham kiem tra dieu kien vay von ngan hang
     */
    public static boolean duDieuKienVay(int tuoi, double thuNhap, boolean coTaiSanBaoLanh, int diemTinDung) {
        // Dieu kien chinh: phai la nguoi truong thanh co thu nhap on dinh
        boolean dieuKienCoBan = (tuoi >= 22) && (thuNhap >= 10_000_000);
        // Dieu kien bao dam: co tai san hoac tin dung tot
        boolean dieuKienBaoDam = coTaiSanBaoLanh || (diemTinDung >= 700);
        // Duoc vay khi ca 2 nhom dieu kien deu thoa man
        return dieuKienCoBan && dieuKienBaoDam;
    }
}
