package dtm.data;

import org.testng.annotations.DataProvider;

/**
 * GioHangData – @DataProvider cho các test case giỏ hàng
 *
 * Cột: tcId | productName | quantity | expectedTotal | action
 */
public class GioHangData {

    /**
     * addToCartData() – Thêm sản phẩm vào giỏ hàng
     */
    @DataProvider(name = "addToCartData", parallel = false)
    public static Object[][] addToCartData() {
        return new Object[][] {
                // tcId | productName | action | expectedBadge
                { "TC_CART_001", "Sauce Labs Backpack", "add", "1" },
                { "TC_CART_002", "Sauce Labs Bike Light", "add", "1" },
                { "TC_CART_003", "Sauce Labs Bolt T-Shirt", "add", "1" },
                { "TC_CART_004", "Sauce Labs Backpack", "remove", "0" },
                { "TC_CART_005", "Sauce Labs Fleece Jacket", "add", "1" },
        };
    }

    /**
     * cartCheckoutData() – Dữ liệu thông tin thanh toán
     */
    @DataProvider(name = "cartCheckoutData", parallel = false)
    public static Object[][] cartCheckoutData() {
        return new Object[][] {
                // tcId | firstName | lastName | zipCode | isValid
                { "TC_CART_006", "Nguyen", "Van A", "70000", true },
                { "TC_CART_007", "", "Van A", "70000", false },
                { "TC_CART_008", "Nguyen", "", "70000", false },
                { "TC_CART_009", "Nguyen", "Van A", "", false },
        };
    }
}
