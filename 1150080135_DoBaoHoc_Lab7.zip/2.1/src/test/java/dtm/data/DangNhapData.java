package dtm.data;

import org.testng.annotations.DataProvider;

/**
 * DangNhapData – @DataProvider cho các test case đăng nhập
 *
 * Cột: username | password | expectedResult | tcId
 * Áp dụng kỹ thuật EP + BVA từ Bài 1.1
 */
public class DangNhapData {

    /**
     * loginData() – Dữ liệu EP: hợp lệ + không hợp lệ
     * Dùng cho: TC_DangNhapTest
     */
    @DataProvider(name = "loginData", parallel = false)
    public static Object[][] loginData() {
        return new Object[][] {
                // TC ID | username | password | expectedResult | isValid
                { "TC_LOGIN_001", "standard_user", "secret_sauce", "Inventory page", true },
                { "TC_LOGIN_002", "locked_out_user", "secret_sauce", "User locked out", false },
                { "TC_LOGIN_003", "", "secret_sauce", "Username required", false },
                { "TC_LOGIN_004", "standard_user", "", "Password required", false },
                { "TC_LOGIN_005", "", "", "Username required", false },
                { "TC_LOGIN_006", "invalid_user", "wrongpass", "Username and password do not match", false },
                { "TC_LOGIN_007", "problem_user", "secret_sauce", "Inventory page", true },
                { "TC_LOGIN_008", "performance_glitch_user", "secret_sauce", "Inventory page", true },
        };
    }

    /**
     * loginDataSmoke() – Chỉ chạy smoke test (happy path + 1 fail)
     */
    @DataProvider(name = "loginDataSmoke", parallel = false)
    public static Object[][] loginDataSmoke() {
        return new Object[][] {
                { "TC_LOGIN_001", "standard_user", "secret_sauce", "Inventory page", true },
                { "TC_LOGIN_003", "", "secret_sauce", "Username required", false },
        };
    }
}
