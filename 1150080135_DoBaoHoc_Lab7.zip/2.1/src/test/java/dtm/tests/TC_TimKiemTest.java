package dtm.tests;

import dtm.base.BaseTest;
import dtm.pages.InventoryPage;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * TC_TimKiemTest – Kiểm thử chức năng Tìm Kiếm / Lọc / Sắp xếp sản phẩm
 */
public class TC_TimKiemTest extends BaseTest {

    private static final String BASE_URL = "https://www.saucedemo.com";
    private InventoryPage inventoryPage;

    @BeforeMethod(alwaysRun = true)
    public void loginBeforeTest(Method method) {
        super.setUp(method);
        inventoryPage = new LoginPage(getDriver())
                .open(BASE_URL)
                .loginAs("standard_user", "secret_sauce");
        Assert.assertTrue(inventoryPage.isOnInventoryPage());
    }

    @DataProvider(name = "sortData")
    public Object[][] sortData() {
        return new Object[][] {
                { "TC_SORT_001", "Name (A to Z)", "Sauce Labs Backpack" },
                { "TC_SORT_002", "Name (Z to A)", "Test.allTheThings() T-Shirt (Red)" },
                { "TC_SORT_003", "Price (low to high)", "Sauce Labs Onesie" },
                { "TC_SORT_004", "Price (high to low)", "Sauce Labs Fleece Jacket" },
        };
    }

    /** TC_SORT_001 → TC_SORT_004: Sắp xếp sản phẩm */
    @Test(dataProvider = "sortData", groups = {
            "regression" }, description = "Kiểm tra sắp xếp sản phẩm theo các tiêu chí")
    public void testSapXep(String tcId, String sortOption, String expectedFirstProduct) {
        System.out.println("[TEST] " + tcId + " | sort by: " + sortOption);

        inventoryPage.sortBy(sortOption);
        String firstProduct = inventoryPage.getFirstProductName();

        Assert.assertEquals(firstProduct, expectedFirstProduct,
                "[" + tcId + "] Sản phẩm đầu tiên sau khi sort không đúng");
        System.out.println("[PASS] " + tcId + " – First product: " + firstProduct);
    }

    /** TC: Trang hiển thị đủ 6 sản phẩm mặc định */
    @Test(groups = { "smoke", "regression" }, description = "Kiểm tra số lượng sản phẩm hiển thị mặc định")
    public void testSoLuongSanPhamMacDinh() {
        int count = inventoryPage.getProductCount();
        Assert.assertEquals(count, 6, "Số sản phẩm hiển thị không đúng (mong đợi 6)");
        System.out.println("[PASS] Hiển thị đúng " + count + " sản phẩm mặc định.");
    }
}
