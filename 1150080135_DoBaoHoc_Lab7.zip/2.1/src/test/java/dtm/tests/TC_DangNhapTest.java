package dtm.tests;

import dtm.base.BaseTest;
import dtm.data.DangNhapData;
import dtm.pages.InventoryPage;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * TC_DangNhapTest – Kiểm thử chức năng Đăng Nhập
 * Sử dụng @DataProvider từ DangNhapData + Page Object LoginPage
 */
public class TC_DangNhapTest extends BaseTest {

    private static final String BASE_URL = "https://www.saucedemo.com";

    /**
     * TC_LOGIN_001 → TC_LOGIN_008: Đăng nhập với nhiều user/pass khác nhau
     * - Hợp lệ: vào trang Inventory
     * - Không hợp lệ: hiển thị thông báo lỗi
     */
    @Test(dataProvider = "loginData", dataProviderClass = DangNhapData.class, groups = {
            "regression" }, description = "Kiểm tra đăng nhập với các tập dữ liệu EP")
    public void testDangNhap(String tcId, String username, String password,
            String expectedResult, boolean isValid) {

        System.out.println("[TEST] " + tcId + " | user=" + username + " | expect=" + expectedResult);

        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.open(BASE_URL);

        if (isValid) {
            // ── TC hợp lệ: phải vào trang Inventory ──
            InventoryPage inventoryPage = loginPage.loginAs(username, password);
            Assert.assertTrue(inventoryPage.isOnInventoryPage(),
                    "[" + tcId + "] Đăng nhập thành công nhưng KHÔNG vào trang sản phẩm!");
            System.out.println("[PASS] " + tcId + " – Đăng nhập thành công → Inventory page.");
        } else {
            // ── TC không hợp lệ: phải hiển thị lỗi ──
            loginPage.enterUsername(username)
                    .enterPassword(password)
                    .clickLogin();

            Assert.assertTrue(loginPage.isErrorDisplayed(),
                    "[" + tcId + "] Đăng nhập thất bại nhưng KHÔNG hiển thị thông báo lỗi!");
            System.out.println("[PASS] " + tcId + " – Hiển thị lỗi: " + loginPage.getErrorMessage());
        }
    }

    /**
     * TC Smoke: Chỉ chạy happy path + 1 fail
     */
    @Test(dataProvider = "loginDataSmoke", dataProviderClass = DangNhapData.class, groups = {
            "smoke" }, description = "Smoke test đăng nhập")
    public void testDangNhapSmoke(String tcId, String username, String password,
            String expectedResult, boolean isValid) {
        testDangNhap(tcId, username, password, expectedResult, isValid);
    }
}
