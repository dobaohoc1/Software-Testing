package dtm.tests;

import dtm.base.BaseTest;
import dtm.data.GioHangData;
import dtm.pages.CartPage;
import dtm.pages.InventoryPage;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * TC_GioHangTest – Kiểm thử chức năng Giỏ Hàng
 */
public class TC_GioHangTest extends BaseTest {

    private static final String BASE_URL = "https://www.saucedemo.com";
    private InventoryPage inventoryPage;

    /** Đăng nhập trước mỗi test */
    @BeforeMethod(alwaysRun = true)
    public void loginBeforeTest(Method method) {
        super.setUp(method);
        LoginPage loginPage = new LoginPage(getDriver());
        inventoryPage = loginPage.open(BASE_URL).loginAs("standard_user", "secret_sauce");
        Assert.assertTrue(inventoryPage.isOnInventoryPage(), "Không vào được trang sản phẩm");
    }

    /** TC_CART_001 → TC_CART_005: Thêm/xóa sản phẩm */
    @Test(dataProvider = "addToCartData", dataProviderClass = GioHangData.class, groups = {
            "regression" }, description = "Kiểm tra thêm sản phẩm vào giỏ hàng")
    public void testThemSanPham(String tcId, String productName,
            String action, String expectedBadge) {
        System.out.println("[TEST] " + tcId + " | product=" + productName + " | action=" + action);

        if ("add".equals(action)) {
            inventoryPage.addToCartByName(productName);
            String badge = inventoryPage.getCartBadgeCount();
            Assert.assertEquals(badge, expectedBadge,
                    "[" + tcId + "] Badge count không khớp sau khi thêm sản phẩm");
            System.out.println("[PASS] " + tcId + " – Thêm giỏ hàng OK, badge = " + badge);
        } else {
            inventoryPage.addToCartByName(productName); // Thêm trước
            CartPage cart = inventoryPage.goToCart();
            cart.removeFirstItem(); // Rồi xóa
            Assert.assertEquals(cart.getCartItemCount(), 0,
                    "[" + tcId + "] Vẫn còn item sau khi xóa");
            System.out.println("[PASS] " + tcId + " – Xóa khỏi giỏ hàng OK");
        }
    }

    /** TC kiểm tra giỏ hàng sau khi điều hướng */
    @Test(groups = { "smoke", "regression" }, description = "Giỏ hàng giữ sản phẩm sau khi quay lại trang chủ")
    public void testGioHangGiuSanPham() {
        inventoryPage.addToCartByName("Sauce Labs Backpack");
        String badgeBefore = inventoryPage.getCartBadgeCount();

        CartPage cart = inventoryPage.goToCart();
        Assert.assertEquals(cart.getCartItemCount(), 1, "Giỏ hàng phải có 1 sản phẩm");

        // Quay lại và kiểm tra badge vẫn còn
        InventoryPage backToInventory = cart.continueShopping();
        Assert.assertEquals(backToInventory.getCartBadgeCount(), badgeBefore,
                "Badge thay đổi sau khi quay lại trang sản phẩm");
        System.out.println("[PASS] Giỏ hàng giữ nguyên sau navigate.");
    }
}
