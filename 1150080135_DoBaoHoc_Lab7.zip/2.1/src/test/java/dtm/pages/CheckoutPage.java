package dtm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * CheckoutPage – Page Object cho trang thanh toán (Step 1 & 2)
 * URL: /checkout-step-one.html → /checkout-step-two.html →
 * /checkout-complete.html
 */
public class CheckoutPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── Locators – Step 1 (Thông tin khách hàng) ──
    private final By firstNameField = By.id("first-name");
    private final By lastNameField = By.id("last-name");
    private final By zipCodeField = By.id("postal-code");
    private final By continueButton = By.id("continue");
    private final By errorMessage = By.cssSelector("[data-test='error']");

    // ── Locators – Step 2 (Xác nhận) ──
    private final By finishButton = By.id("finish");
    private final By totalLabel = By.className("summary_total_label");

    // ── Locators – Complete ──
    private final By completeHeader = By.className("complete-header");

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // ── Step 1: Điền thông tin ──

    public CheckoutPage enterFirstName(String firstName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameField))
                .sendKeys(firstName);
        return this;
    }

    public CheckoutPage enterLastName(String lastName) {
        driver.findElement(lastNameField).sendKeys(lastName);
        return this;
    }

    public CheckoutPage enterZipCode(String zip) {
        driver.findElement(zipCodeField).sendKeys(zip);
        return this;
    }

    public CheckoutPage clickContinue() {
        driver.findElement(continueButton).click();
        return this;
    }

    /** Điền đầy đủ thông tin và next */
    public CheckoutPage fillInfo(String firstName, String lastName, String zip) {
        enterFirstName(firstName);
        enterLastName(lastName);
        enterZipCode(zip);
        clickContinue();
        return this;
    }

    // ── Step 2: Xác nhận ──

    public String getTotalPrice() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(totalLabel)).getText();
        } catch (Exception e) {
            return "";
        }
    }

    public CheckoutPage clickFinish() {
        wait.until(ExpectedConditions.elementToBeClickable(finishButton)).click();
        return this;
    }

    // ── Verifications ──

    /** Đặt hàng hoàn thành */
    public boolean isOrderComplete() {
        try {
            String text = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(completeHeader)).getText();
            return text.toLowerCase().contains("thank you");
        } catch (Exception e) {
            return false;
        }
    }

    /** Lỗi thiếu thông tin */
    public String getErrorMessage() {
        try {
            return wait.until(
                    ExpectedConditions.visibilityOfElementLocated(errorMessage)).getText();
        } catch (Exception e) {
            return "";
        }
    }

    public boolean isErrorDisplayed() {
        return !getErrorMessage().isEmpty();
    }
}
