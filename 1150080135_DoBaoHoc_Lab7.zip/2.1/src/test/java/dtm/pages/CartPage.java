package dtm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * CartPage – Page Object cho trang giỏ hàng
 * URL: https://www.saucedemo.com/cart.html
 */
public class CartPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── Locators ──
    private final By pageTitle = By.className("title");
    private final By cartItems = By.className("cart_item");
    private final By checkoutButton = By.id("checkout");
    private final By continueShoppingButton = By.id("continue-shopping");
    private final By removeButtons = By.cssSelector("button[id^='remove']");

    public CartPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // ── Verifications ──

    /** Kiểm tra đang ở trang Cart */
    public boolean isOnCartPage() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(pageTitle));
            return driver.findElement(pageTitle).getText().equalsIgnoreCase("Your Cart");
        } catch (Exception e) {
            return false;
        }
    }

    /** Số lượng item trong giỏ hàng */
    public int getCartItemCount() {
        return driver.findElements(cartItems).size();
    }

    /** Lấy danh sách tên sản phẩm trong giỏ */
    public List<String> getCartItemNames() {
        return driver.findElements(By.className("inventory_item_name"))
                .stream()
                .map(WebElement::getText)
                .toList();
    }

    /** Kiểm tra sản phẩm có trong giỏ không */
    public boolean containsProduct(String productName) {
        return getCartItemNames().stream()
                .anyMatch(name -> name.equalsIgnoreCase(productName));
    }

    // ── Actions ──

    /** Xóa sản phẩm đầu tiên */
    public CartPage removeFirstItem() {
        List<WebElement> removes = driver.findElements(removeButtons);
        if (!removes.isEmpty())
            removes.get(0).click();
        return this;
    }

    /** Tiến hành thanh toán */
    public CheckoutPage proceedToCheckout() {
        wait.until(ExpectedConditions.elementToBeClickable(checkoutButton)).click();
        return new CheckoutPage(driver);
    }

    /** Quay lại trang sản phẩm */
    public InventoryPage continueShopping() {
        driver.findElement(continueShoppingButton).click();
        return new InventoryPage(driver);
    }
}
