package dtm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * InventoryPage – Page Object cho trang danh sách sản phẩm
 * URL: https://www.saucedemo.com/inventory.html
 */
public class InventoryPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── Locators ──
    private final By pageTitle = By.className("title");
    private final By productItems = By.className("inventory_item");
    private final By sortDropdown = By.className("product_sort_container");
    private final By cartBadge = By.className("shopping_cart_badge");
    private final By cartIcon = By.className("shopping_cart_link");

    public InventoryPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // glitch_user cần lâu hơn
    }

    // ── Verifications ──

    /** Kiểm tra đang ở trang Inventory */
    public boolean isOnInventoryPage() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(pageTitle));
            return driver.findElement(pageTitle).getText().equalsIgnoreCase("Products");
        } catch (Exception e) {
            return false;
        }
    }

    /** Lấy số lượng sản phẩm đang hiển thị */
    public int getProductCount() {
        return driver.findElements(productItems).size();
    }

    // ── Actions ──

    /** Thêm sản phẩm vào giỏ hàng theo tên */
    public InventoryPage addToCartByName(String productName) {
        String btnId = "add-to-cart-"
                + productName.toLowerCase()
                        .replace(" ", "-")
                        .replace(".", "");
        try {
            driver.findElement(By.id(btnId)).click();
        } catch (Exception e) {
            // Fallback: tìm trong các item
            List<WebElement> items = driver.findElements(productItems);
            for (WebElement item : items) {
                if (item.findElement(By.className("inventory_item_name"))
                        .getText().equalsIgnoreCase(productName)) {
                    item.findElement(By.tagName("button")).click();
                    break;
                }
            }
        }
        return this;
    }

    /** Lấy số hiển thị trên badge giỏ hàng */
    public String getCartBadgeCount() {
        try {
            return driver.findElement(cartBadge).getText();
        } catch (Exception e) {
            return "0";
        }
    }

    /**
     * Sắp xếp theo option (A to Z, Z to A, Price low to high, Price high to low)
     */
    public InventoryPage sortBy(String option) {
        Select select = new Select(driver.findElement(sortDropdown));
        select.selectByVisibleText(option);
        return this;
    }

    /** Tìm kiếm (nếu có search box) hoặc filter theo tên */
    public String getFirstProductName() {
        return driver.findElements(By.className("inventory_item_name"))
                .get(0).getText();
    }

    /** Nhấn vào giỏ hàng */
    public CartPage goToCart() {
        driver.findElement(cartIcon).click();
        return new CartPage(driver);
    }
}
