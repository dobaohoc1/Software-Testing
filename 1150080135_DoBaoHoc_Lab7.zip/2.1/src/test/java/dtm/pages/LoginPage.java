package dtm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * LoginPage – Page Object cho trang đăng nhập SauceDemo
 * URL: https://www.saucedemo.com
 */
public class LoginPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── Locators ──
    private final By usernameField = By.id("user-name");
    private final By passwordField = By.id("password");
    private final By loginButton = By.id("login-button");
    private final By errorMessage = By.cssSelector("[data-test='error']");
    private final By loginLogo = By.className("login_logo");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // ── Actions ──

    /** Mở trang đăng nhập */
    public LoginPage open(String baseUrl) {
        driver.get(baseUrl);
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginLogo));
        return this;
    }

    /** Nhập username */
    public LoginPage enterUsername(String username) {
        WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(usernameField));
        field.clear();
        field.sendKeys(username);
        return this;
    }

    /** Nhập password */
    public LoginPage enterPassword(String password) {
        WebElement field = driver.findElement(passwordField);
        field.clear();
        field.sendKeys(password);
        return this;
    }

    /** Nhấn nút Login */
    public LoginPage clickLogin() {
        driver.findElement(loginButton).click();
        return this;
    }

    /** Đăng nhập đầy đủ: điền + click */
    public InventoryPage loginAs(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLogin();
        return new InventoryPage(driver);
    }

    // ── Verifications ──

    /** Lấy text thông báo lỗi (nếu có) */
    public String getErrorMessage() {
        try {
            WebElement err = wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessage));
            return err.getText();
        } catch (Exception e) {
            return "";
        }
    }

    /** Kiểm tra có hiển thị lỗi không */
    public boolean isErrorDisplayed() {
        return !getErrorMessage().isEmpty();
    }

    /** Kiểm tra đang ở trang login */
    public boolean isOnLoginPage() {
        return driver.getCurrentUrl().contains("saucedemo.com")
                && driver.findElements(loginButton).size() > 0;
    }
}
