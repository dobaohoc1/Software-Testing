package dtm;

/**
 * Placeholder class cho src/main/java/dtm/
 * Có thể thêm các utility class dùng chung tại đây.
 *
 * Ví dụ: ConfigReader, WaitHelper, ReportHelper...
 */
public class AppConfig {
    public static final String BASE_URL = "https://www.saucedemo.com";
    public static final int IMPLICIT_WAIT_SECONDS = 10;
    public static final int EXPLICIT_WAIT_SECONDS = 15;
    public static final String SCREENSHOT_DIR = "screenshots";
}
