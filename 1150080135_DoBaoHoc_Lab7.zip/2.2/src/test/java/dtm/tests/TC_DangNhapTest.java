package dtm.tests;

import dtm.base.BaseTest;
import dtm.data.DangNhapData;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * TC_DangNhapTest – Yêu cầu 2.3
 *
 * Đọc dữ liệu từ @DataProvider "du_lieu_dang_nhap",
 * thực hiện đăng nhập và Assert kết quả theo ketQuaMongDoi.
 *
 * ketQuaMongDoi có 4 loại:
 * THANH_CONG – Chuyển vào /inventory.html
 * SAI_THONG_TIN – Ở lại trang login, hiện thông báo lỗi
 * BI_KHOA – Ở lại trang login, lỗi "locked out"
 * TRUONG_TRONG – Ở lại trang login, lỗi "required"
 */
public class TC_DangNhapTest extends BaseTest {

    private static final String URL = "https://www.saucedemo.com";

    @Test(dataProvider = "du_lieu_dang_nhap", dataProviderClass = DangNhapData.class, description = "Kiểm thử đăng nhập với nhiều bộ dữ liệu")
    public void kiemThuDangNhap(String username, String password,
            String ketQuaMongDoi, String moTa) {

        System.out.println("\n──────────────────────────────────────────");
        System.out.printf("[TEST] %s%n", moTa);
        System.out.printf("       username='%s' | password='%s' | mong=%s%n",
                username, password, ketQuaMongDoi);

        // 1. Khởi tạo LoginPage và mở trang
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.moTrang(URL);

        // 2. Thực hiện đăng nhập
        loginPage.dangNhap(username, password);

        // 3. Assert kết quả dựa vào ketQuaMongDoi
        if ("THANH_CONG".equals(ketQuaMongDoi)) {
            // Phải chuyển sang trang sản phẩm
            boolean vaoTrangSanPham = loginPage.isDangOTrangSanPham();
            Assert.assertTrue(vaoTrangSanPham,
                    "[FAIL] " + moTa
                            + "\nMong doi: chuyen vao /inventory.html"
                            + "\nThuc te : " + getDriver().getCurrentUrl());
            System.out.println("[PASS] Dang nhap thanh cong -> inventory.html");

        } else if ("SAI_THONG_TIN".equals(ketQuaMongDoi)) {
            // Phải ở lại trang login và hiển thị lỗi
            Assert.assertTrue(loginPage.isDangOTrangDangNhap(),
                    "[FAIL] " + moTa + " - Khong o lai trang login");
            String loiHienThi = loginPage.layThongBaoLoi();
            Assert.assertNotNull(loiHienThi,
                    "[FAIL] " + moTa + " - Khong hien thi thong bao loi");
            Assert.assertTrue(
                    loiHienThi.toLowerCase().contains("do not match")
                            || loiHienThi.toLowerCase().contains("username and password"),
                    "[FAIL] " + moTa + " - Thong bao loi khong dung: " + loiHienThi);
            System.out.println("[PASS] Sai thong tin - loi: " + loiHienThi);

        } else if ("BI_KHOA".equals(ketQuaMongDoi)) {
            // Phải ở lại trang login và hiển thị lỗi khoá tài khoản
            Assert.assertTrue(loginPage.isDangOTrangDangNhap(),
                    "[FAIL] " + moTa + " - Khong o lai trang login");
            String loiKhoa = loginPage.layThongBaoLoi();
            Assert.assertNotNull(loiKhoa,
                    "[FAIL] " + moTa + " - Khong hien thi thong bao loi khoa");
            Assert.assertTrue(loiKhoa.toLowerCase().contains("locked out"),
                    "[FAIL] " + moTa + " - Thong bao loi khong chua 'locked out': " + loiKhoa);
            System.out.println("[PASS] Tai khoan bi khoa - loi: " + loiKhoa);

        } else if ("TRUONG_TRONG".equals(ketQuaMongDoi)) {
            // Phải ở lại trang login và hiển thị lỗi required
            Assert.assertTrue(loginPage.isDangOTrangDangNhap(),
                    "[FAIL] " + moTa + " - Khong o lai trang login");
            if (username == null || password == null) {
                System.out.println("[PASS] Gia tri null xu ly an toan, khong crash");
            } else {
                String loiTrong = loginPage.layThongBaoLoi();
                Assert.assertNotNull(loiTrong,
                        "[FAIL] " + moTa + " - Khong hien thi thong bao loi khi truong trong");
                Assert.assertTrue(
                        loiTrong.toLowerCase().contains("required"),
                        "[FAIL] " + moTa + " - Thong bao khong chua 'required': " + loiTrong);
                System.out.println("[PASS] Truong trong - loi: " + loiTrong);
            }

        } else {
            Assert.fail("[FAIL] ketQuaMongDoi khong xac dinh: " + ketQuaMongDoi);
        }
    }
}
