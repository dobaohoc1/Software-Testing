package dtm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * InventoryPage – Page Object cho /inventory.html
 * Yeu cau 2.3.B: Su dung @FindBy + PageFactory
 */
public class InventoryPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── @FindBy Locators ──
    @FindBy(className = "product_sort_container")
    private WebElement sortDropdown;

    @FindBy(css = "button[id^='add-to-cart']")
    private List<WebElement> addToCartButtons;

    @FindBy(css = "button[id^='remove']")
    private List<WebElement> removeButtons;

    @FindBy(className = "shopping_cart_badge")
    private WebElement cartBadge;

    @FindBy(className = "shopping_cart_link")
    private WebElement cartLink;

    @FindBy(className = "inventory_item_name")
    private List<WebElement> productNames;

    @FindBy(className = "inventory_item_price")
    private List<WebElement> productPrices;

    @FindBy(className = "inventory_item")
    private List<WebElement> productItems;

    public InventoryPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        PageFactory.initElements(driver, this);
    }

    /** Kiem tra dang o trang Inventory */
    public boolean isDangOTrangInventory() {
        try {
            wait.until(ExpectedConditions.urlContains("/inventory.html"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Them san pham theo ten */
    public void themSanPhamTheoTen(String tenSanPham) {
        wait.until(ExpectedConditions.visibilityOfAllElements(productItems));
        for (WebElement item : productItems) {
            WebElement nameEl = item.findElement(
                    org.openqa.selenium.By.className("inventory_item_name"));
            if (nameEl.getText().equalsIgnoreCase(tenSanPham)) {
                WebElement btn = item.findElement(
                        org.openqa.selenium.By.tagName("button"));
                btn.click();
                return;
            }
        }
        throw new RuntimeException("Khong tim thay san pham: " + tenSanPham);
    }

    /** Them N san pham dau tien trong danh sach */
    public void themNSanPhamDauTien(int n) {
        wait.until(ExpectedConditions.visibilityOfAllElements(productItems));
        // Refresh list vi DOM thay doi sau moi click
        for (int i = 0; i < n; i++) {
            List<WebElement> btns = driver.findElements(
                    org.openqa.selenium.By.cssSelector("button[id^='add-to-cart']"));
            if (btns.isEmpty())
                break;
            btns.get(0).click();
        }
    }

    /** Tra ve so luong badge gio hang, 0 neu khong co badge */
    public int laySoLuongBadge() {
        try {
            List<WebElement> badges = driver.findElements(
                    org.openqa.selenium.By.className("shopping_cart_badge"));
            if (badges.isEmpty())
                return 0;
            return Integer.parseInt(badges.get(0).getText());
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Sort san pham theo tuy chon.
     * option: 'az' | 'za' | 'lohi' | 'hilo'
     */
    public void sortSanPham(String option) {
        wait.until(ExpectedConditions.visibilityOf(sortDropdown));
        new Select(sortDropdown).selectByValue(option);
    }

    /** Lay danh sach ten san pham theo thu tu hien thi */
    public List<String> layDanhSachTenSanPham() {
        wait.until(ExpectedConditions.visibilityOfAllElements(productNames));
        List<String> names = new ArrayList<>();
        for (WebElement el : productNames) {
            names.add(el.getText());
        }
        return names;
    }

    /** Lay danh sach gia san pham theo thu tu hien thi (double) */
    public List<Double> layDanhSachGiaSanPham() {
        wait.until(ExpectedConditions.visibilityOfAllElements(productPrices));
        List<Double> prices = new ArrayList<>();
        for (WebElement el : productPrices) {
            prices.add(Double.parseDouble(el.getText().replace("$", "")));
        }
        return prices;
    }

    /** So luong san pham hien thi */
    public int laySoSanPham() {
        return productItems.size();
    }

    /** Di chuyen sang trang gio hang */
    public CartPage diDenGioHang() {
        wait.until(ExpectedConditions.elementToBeClickable(cartLink)).click();
        return new CartPage(driver);
    }
}
