package dtm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/** CartPage – Page Object cho /cart.html */
public class CartPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    @FindBy(className = "cart_item")
    private List<WebElement> cartItems;

    @FindBy(id = "checkout")
    private WebElement checkoutBtn;

    @FindBy(id = "continue-shopping")
    private WebElement continueShoppingBtn;

    @FindBy(css = "button[id^='remove']")
    private List<WebElement> removeButtons;

    @FindBy(className = "shopping_cart_badge")
    private WebElement cartBadge;

    @FindBy(className = "inventory_item_name")
    private List<WebElement> itemNames;

    public CartPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    public boolean isDangOTrangGioHang() {
        try {
            wait.until(ExpectedConditions.urlContains("/cart.html"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public int laysoLuongItems() {
        return driver.findElements(org.openqa.selenium.By.className("cart_item")).size();
    }

    public List<String> layDanhSachTenItem() {
        List<String> names = new ArrayList<>();
        for (WebElement el : driver.findElements(
                org.openqa.selenium.By.className("inventory_item_name"))) {
            names.add(el.getText());
        }
        return names;
    }

    /** Xoa item theo ten */
    public void xoaItemTheoTen(String ten) {
        String btnId = "remove-" + ten.toLowerCase()
                .replace(" ", "-").replace(".", "");
        driver.findElement(org.openqa.selenium.By.id(btnId)).click();
    }

    /** Xoa tat ca items */
    public void xoaTatCaItems() {
        List<WebElement> btns = driver.findElements(
                org.openqa.selenium.By.cssSelector("button[id^='remove']"));
        while (!btns.isEmpty()) {
            btns.get(0).click();
            btns = driver.findElements(
                    org.openqa.selenium.By.cssSelector("button[id^='remove']"));
        }
    }

    public boolean isCheckoutBtnHienThi() {
        try {
            return wait.until(ExpectedConditions.visibilityOf(checkoutBtn)).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public CheckoutPage nhanCheckout() {
        wait.until(ExpectedConditions.elementToBeClickable(checkoutBtn)).click();
        return new CheckoutPage(driver);
    }

    public InventoryPage nhanContinueShopping() {
        wait.until(ExpectedConditions.elementToBeClickable(continueShoppingBtn)).click();
        return new InventoryPage(driver);
    }
}
