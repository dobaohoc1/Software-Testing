package dtm.tests;

import dtm.base.BaseTest;
import dtm.pages.RegisterPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * TC_DangKyTest – Tu dong hoa 8+ test case dang ky automationpractice.pl
 * Yeu cau 3.1: EP + BVA, xu ly dropdown, state, scroll to submit
 */
public class TC_DangKyTest extends BaseTest {

    RegisterPage registerPage;

    /** Tao email duy nhat moi lan chay de tranh trung */
    private String uniqueEmail() {
        return "testuser" + System.currentTimeMillis() + "@mailtest.com";
    }

    @BeforeMethod(alwaysRun = true)
    public void chuanBi(Method method) {
        super.setUp(method);
        registerPage = new RegisterPage(getDriver());
        registerPage.moTrang();
    }

    // ══════════════════════════════════════════════════════════════════
    // NHOM 1: Step 1 – Kiem tra email (EP + BVA)
    // ══════════════════════════════════════════════════════════════════

    @Test(groups = "smoke", description = "TC_REG_001: Email hop le chua ton tai → chuyen sang Step 2")
    public void emailHopLeChuaTonTai() {
        registerPage.nhapEmailVaClickTao(uniqueEmail());
        Assert.assertTrue(registerPage.isDangOStep2(),
                "Email hop le phai chuyen sang form dang ky Step 2");
        System.out.println("[PASS] TC_REG_001 – Chuyen sang Step 2 OK");
    }

    @Test(groups = "regression", description = "TC_REG_002: Email da ton tai → hien loi 'already registered'")
    public void emailDaTonTai() {
        // Email mac dinh da co san tren automationpractice
        registerPage.nhapEmailVaClickTao("test@email.com");
        String loi = registerPage.layLoiStep1();
        // Neu chua ton tai thi trang chuyen Step 2 (khong FAIL test nay)
        if (loi != null) {
            Assert.assertTrue(
                    loi.toLowerCase().contains("already") ||
                            loi.toLowerCase().contains("registered") ||
                            loi.toLowerCase().contains("exist"),
                    "Loi phai noi ve 'already registered': " + loi);
            System.out.println("[PASS] TC_REG_002 – Loi email ton tai: " + loi);
        } else {
            System.out.println("[INFO] TC_REG_002 – Email nay chua ton tai tren server, bo qua");
        }
    }

    @Test(groups = "regression", description = "TC_REG_003: Email khong co @ → hien loi invalid")
    public void emailKhongCoAt() {
        registerPage.nhapEmailVaClickTao("emailkhonghople");
        String loi = registerPage.layLoiStep1();
        boolean step2 = registerPage.isDangOStep2();
        Assert.assertFalse(step2, "Email sai format khong duoc vao Step 2");
        System.out.println("[PASS] TC_REG_003 – Email khong hop le, loi: " + loi);
    }

    @Test(groups = "regression", description = "TC_REG_004: Email de trong → hien loi")
    public void emailDeTrong() {
        registerPage.nhapEmailVaClickTao("");
        String loi = registerPage.layLoiStep1();
        boolean step2 = registerPage.isDangOStep2();
        Assert.assertFalse(step2, "Email trong khong duoc vao Step 2");
        System.out.println("[PASS] TC_REG_004 – Email trong, loi: " + loi);
    }

    // ══════════════════════════════════════════════════════════════════
    // NHOM 2: Step 2 – First Name BVA (1–32 ky tu)
    // ══════════════════════════════════════════════════════════════════

    @Test(groups = "regression", description = "TC_REG_005: First Name = 1 ky tu (BVA min) → hop le")
    public void firstNameMotKyTu() {
        registerPage.nhapEmailVaClickTao(uniqueEmail());
        Assert.assertTrue(registerPage.isDangOStep2());
        registerPage
                .dienDayDuThongTin("A", "Nguyen", "pass12345",
                        "123 Main St", "New York", "New York", "10001")
                .nhanRegister();
        boolean ok = registerPage.isDangKyThanhCong();
        String loi = registerPage.layLoiStep2();
        // First Name 1 ky tu co the bi loi "invalid" – ghi nhan
        if (ok) {
            System.out.println("[PASS] TC_REG_005 – First Name 1 ky tu: tao tai khoan OK");
        } else {
            System.out.println("[INFO] TC_REG_005 – First Name 1 ky tu bi tu choi. Loi: " + loi);
        }
    }

    @Test(groups = "regression", description = "TC_REG_006: First Name = 32 ky tu (BVA max) → hop le")
    public void firstName32KyTu() {
        registerPage.nhapEmailVaClickTao(uniqueEmail());
        Assert.assertTrue(registerPage.isDangOStep2());
        String fn32 = "A".repeat(32); // 32 ky tu
        registerPage
                .dienDayDuThongTin(fn32, "Nguyen", "pass12345",
                        "123 Main St", "New York", "New York", "10001")
                .nhanRegister();
        String loi = registerPage.layLoiStep2();
        if (loi != null && loi.toLowerCase().contains("firstname")) {
            Assert.fail("TC_REG_006 – First Name 32 ky tu bi loi: " + loi);
        }
        System.out.println("[PASS] TC_REG_006 – First Name 32 ky tu chap nhan");
    }

    @Test(groups = "regression", description = "TC_REG_007: First Name de trong → loi 'required'")
    public void firstNameDeTrong() {
        registerPage.nhapEmailVaClickTao(uniqueEmail());
        Assert.assertTrue(registerPage.isDangOStep2());
        registerPage
                .dienDayDuThongTin("", "Nguyen", "pass12345",
                        "123 Main St", "New York", "New York", "10001")
                .nhanRegister();
        Assert.assertFalse(registerPage.isDangKyThanhCong(),
                "First Name trong phai bi tu choi");
        System.out.println("[PASS] TC_REG_007 – First Name trong: bi tu choi dung");
    }

    // ══════════════════════════════════════════════════════════════════
    // NHOM 3: Step 2 – Password BVA (min 5 ky tu)
    // ══════════════════════════════════════════════════════════════════

    @Test(groups = "regression", description = "TC_REG_008: Password = 4 ky tu (BVA min-1) → loi")
    public void password4KyTu() {
        registerPage.nhapEmailVaClickTao(uniqueEmail());
        Assert.assertTrue(registerPage.isDangOStep2());
        registerPage
                .dienDayDuThongTin("Nguyen", "Van A", "abcd", // 4 ky tu
                        "123 Main St", "New York", "New York", "10001")
                .nhanRegister();
        Assert.assertFalse(registerPage.isDangKyThanhCong(),
                "Password 4 ky tu phai bi tu choi (min = 5)");
        System.out.println("[PASS] TC_REG_008 – Password 4 ky tu bi tu choi dung");
    }

    @Test(groups = "smoke", description = "TC_REG_009: Password = 5 ky tu (BVA min) → hop le")
    public void password5KyTu() {
        registerPage.nhapEmailVaClickTao(uniqueEmail());
        Assert.assertTrue(registerPage.isDangOStep2());
        registerPage
                .dienDayDuThongTin("Nguyen", "Van A", "abcde", // 5 ky tu
                        "123 Main St", "New York", "New York", "10001")
                .nhanRegister();
        boolean ok = registerPage.isDangKyThanhCong();
        String loi = registerPage.layLoiStep2();
        if (loi != null && loi.toLowerCase().contains("passwd")) {
            Assert.fail("TC_REG_009 – Password 5 ky tu bi loi: " + loi);
        }
        System.out.println(
                "[PASS] TC_REG_009 – Password 5 ky tu: " + (ok ? "dang ky OK" : "step 2 bi loi khac - " + loi));
    }

    // ══════════════════════════════════════════════════════════════════
    // NHOM 4: Step 2 – Happy path + Dropdown + Scroll
    // ══════════════════════════════════════════════════════════════════

    @Test(groups = "smoke", description = "TC_REG_010: Dang ky day du thong tin → thanh cong (dung dropdown + scroll)")
    public void dangKyDayDuThanhCong() {
        registerPage.nhapEmailVaClickTao(uniqueEmail());
        Assert.assertTrue(registerPage.isDangOStep2(), "Phai vao duoc Step 2");

        registerPage
                .chonTitle("Mr")
                .nhapHoTen("Nguyen", "Van A")
                .nhapPassword("Secure@123")
                .chonNgaySinh("15", "5", "1995") // dropdown ngay/thang/nam
                .nhapHoTenDiaChi("Nguyen", "Van A")
                .nhapDiaChi("123 Elm Street")
                .nhapCity("New York")
                .chonState("New York") // state dropdown
                .nhapZip("10001")
                .nhapMobile("0901234567")
                .nhanRegister(); // scroll + click

        Assert.assertTrue(registerPage.isDangKyThanhCong(),
                "Dang ky thanh cong phai chuyen sang /my-account");
        System.out.println("[PASS] TC_REG_010 – Dang ky thanh cong!");
    }

    @Test(groups = "regression", description = "TC_REG_011: Bo trong Address → loi 'address required'")
    public void diaChiboTrong() {
        registerPage.nhapEmailVaClickTao(uniqueEmail());
        Assert.assertTrue(registerPage.isDangOStep2());
        registerPage
                .chonTitle("Mr")
                .nhapHoTen("Nguyen", "Van A")
                .nhapPassword("Secure@123")
                .nhapHoTenDiaChi("Nguyen", "Van A")
                .nhapDiaChi("") // trong
                .nhapCity("New York")
                .chonState("New York")
                .nhapZip("10001")
                .nhanRegister();
        Assert.assertFalse(registerPage.isDangKyThanhCong(),
                "Bo trong Address phai bi tu choi");
        System.out.println("[PASS] TC_REG_011 – Address trong bi tu choi dung");
    }

    @Test(groups = "regression", description = "TC_REG_012: Zip code sai dinh dang → loi")
    public void zipCodeSai() {
        registerPage.nhapEmailVaClickTao(uniqueEmail());
        Assert.assertTrue(registerPage.isDangOStep2());
        registerPage
                .chonTitle("Mr")
                .nhapHoTen("Nguyen", "Van A")
                .nhapPassword("Secure@123")
                .nhapHoTenDiaChi("Nguyen", "Van A")
                .nhapDiaChi("123 Elm Street")
                .nhapCity("New York")
                .chonState("New York")
                .nhapZip("ABCDE") // sai dinh dang
                .nhanRegister();
        Assert.assertFalse(registerPage.isDangKyThanhCong(),
                "Zip sai dinh dang phai bi tu choi");
        System.out.println("[PASS] TC_REG_012 – Zip sai dinh dang bi tu choi");
    }
}
