package dtm.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * RegisterPage – Page Object cho form Dang Ky automationpractice.pl
 *
 * Gom ca Step 1 (nhap email) va Step 2 (thong tin ca nhan + dia chi)
 * Su dung @FindBy + PageFactory.initElements
 */
public class RegisterPage {

    private final WebDriver driver;
    private final WebDriverWait wait;
    private final JavascriptExecutor js;

    private static final String URL = "http://www.automationpractice.pl/index.php?controller=authentication&back=my-account";

    // ────── STEP 1 ──────
    @FindBy(id = "email_create")
    private WebElement emailCreateField;

    @FindBy(id = "SubmitCreate")
    private WebElement submitCreateBtn;

    @FindBy(id = "create_account_error")
    private WebElement createAccountError;

    // ────── STEP 2 – Thong tin ca nhan ──────
    @FindBy(id = "id_gender1")
    private WebElement radioMr;

    @FindBy(id = "id_gender2")
    private WebElement radioMrs;

    @FindBy(id = "customer_firstname")
    private WebElement customerFirstName;

    @FindBy(id = "customer_lastname")
    private WebElement customerLastName;

    @FindBy(id = "email")
    private WebElement emailStep2;

    @FindBy(id = "passwd")
    private WebElement passwordField;

    @FindBy(id = "days")
    private WebElement dobDay;

    @FindBy(id = "months")
    private WebElement dobMonth;

    @FindBy(id = "years")
    private WebElement dobYear;

    @FindBy(id = "newsletter")
    private WebElement newsletterCheckbox;

    // ────── STEP 2 – Dia chi ──────
    @FindBy(id = "firstname")
    private WebElement addressFirstName;

    @FindBy(id = "lastname")
    private WebElement addressLastName;

    @FindBy(id = "address1")
    private WebElement address;

    @FindBy(id = "city")
    private WebElement city;

    @FindBy(id = "id_state")
    private WebElement stateDropdown;

    @FindBy(id = "postcode")
    private WebElement zipCode;

    @FindBy(id = "id_country")
    private WebElement countryDropdown;

    @FindBy(id = "phone_mobile")
    private WebElement mobilePhone;

    @FindBy(id = "submitAccount")
    private WebElement submitAccountBtn;

    // ────── Thong bao loi / thanh cong ──────
    @FindBy(css = ".alert-danger")
    private WebElement alertDanger;

    @FindBy(css = ".alert-success")
    private WebElement alertSuccess;

    @FindBy(id = "center_column")
    private WebElement centerColumn;

    // ────── Constructor ──────
    public RegisterPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        this.js = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

    // ══════════════════════════════════════════
    // STEP 1
    // ══════════════════════════════════════════

    public RegisterPage moTrang() {
        driver.get(URL);
        wait.until(ExpectedConditions.visibilityOf(emailCreateField));
        return this;
    }

    /** Nhap email o Step 1 va click Create an account */
    public RegisterPage nhapEmailVaClickTao(String email) {
        emailCreateField.clear();
        if (email != null)
            emailCreateField.sendKeys(email);
        submitCreateBtn.click();
        return this;
    }

    /** Kiem tra dang o Step 2 (form dang ky mo ra) */
    public boolean isDangOStep2() {
        try {
            wait.until(ExpectedConditions.visibilityOf(customerFirstName));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Lay thong bao loi o Step 1 */
    public String layLoiStep1() {
        try {
            wait.until(ExpectedConditions.visibilityOf(createAccountError));
            return createAccountError.getText();
        } catch (Exception e) {
            return null;
        }
    }

    // ══════════════════════════════════════════
    // STEP 2 – Thong tin ca nhan
    // ══════════════════════════════════════════

    public RegisterPage chonTitle(String title) {
        if ("Mr".equalsIgnoreCase(title))
            radioMr.click();
        else
            radioMrs.click();
        return this;
    }

    public RegisterPage nhapHoTen(String fn, String ln) {
        customerFirstName.clear();
        if (fn != null)
            customerFirstName.sendKeys(fn);
        customerLastName.clear();
        if (ln != null)
            customerLastName.sendKeys(ln);
        return this;
    }

    public RegisterPage nhapPassword(String pass) {
        passwordField.clear();
        if (pass != null)
            passwordField.sendKeys(pass);
        return this;
    }

    /**
     * Chon ngay/thang/nam sinh – dung Select (dropdown)
     * day: "1"-"31", month: "1"-"12", year: "1900"-"2024"
     */
    public RegisterPage chonNgaySinh(String day, String month, String year) {
        new Select(dobDay).selectByValue(day);
        new Select(dobMonth).selectByValue(month);
        new Select(dobYear).selectByValue(year);
        return this;
    }

    // ══════════════════════════════════════════
    // STEP 2 – Dia chi
    // ══════════════════════════════════════════

    public RegisterPage nhapHoTenDiaChi(String fn, String ln) {
        addressFirstName.clear();
        if (fn != null)
            addressFirstName.sendKeys(fn);
        addressLastName.clear();
        if (ln != null)
            addressLastName.sendKeys(ln);
        return this;
    }

    public RegisterPage nhapDiaChi(String addr) {
        address.clear();
        if (addr != null)
            address.sendKeys(addr);
        return this;
    }

    public RegisterPage nhapCity(String c) {
        city.clear();
        if (c != null)
            city.sendKeys(c);
        return this;
    }

    /**
     * Chon State theo ten (visible text) – State dropdown chi co voi Country = USA
     */
    public RegisterPage chonState(String stateName) {
        wait.until(ExpectedConditions.visibilityOf(stateDropdown));
        new Select(stateDropdown).selectByVisibleText(stateName);
        return this;
    }

    public RegisterPage nhapZip(String zip) {
        zipCode.clear();
        if (zip != null)
            zipCode.sendKeys(zip);
        return this;
    }

    public RegisterPage nhapMobile(String phone) {
        mobilePhone.clear();
        if (phone != null)
            mobilePhone.sendKeys(phone);
        return this;
    }

    /**
     * Scroll xuong va click nut Register – xu ly scroll to submit button
     */
    public RegisterPage nhanRegister() {
        js.executeScript("arguments[0].scrollIntoView({block:'center'});", submitAccountBtn);
        wait.until(ExpectedConditions.elementToBeClickable(submitAccountBtn)).click();
        return this;
    }

    // ══════════════════════════════════════════
    // Ket qua / Verifications
    // ══════════════════════════════════════════

    /** Dang ky thanh cong: URL chuyen qua /my-account */
    public boolean isDangKyThanhCong() {
        try {
            wait.until(ExpectedConditions.urlContains("my-account"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Lay toan bo thong bao loi o Step 2 */
    public String layLoiStep2() {
        try {
            wait.until(ExpectedConditions.visibilityOf(alertDanger));
            return alertDanger.getText();
        } catch (Exception e) {
            // Thu tim li ol
            try {
                WebElement ol = driver.findElement(By.cssSelector(".alert.alert-danger ol"));
                return ol.getText();
            } catch (Exception ex) {
                return null;
            }
        }
    }

    public boolean isCoLoi() {
        return layLoiStep2() != null;
    }

    /**
     * Dien day du thong tin step 2 – helper dung cho happy path
     */
    public RegisterPage dienDayDuThongTin(String fn, String ln,
            String pass,
            String addr, String c,
            String state, String zip) {
        chonTitle("Mr");
        nhapHoTen(fn, ln);
        nhapPassword(pass);
        chonNgaySinh("15", "5", "1995");
        nhapHoTenDiaChi(fn, ln);
        nhapDiaChi(addr);
        nhapCity(c);
        chonState(state);
        nhapZip(zip);
        nhapMobile("0901234567");
        return this;
    }
}
