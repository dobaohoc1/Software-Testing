using System;
using System.Windows.Forms;

namespace OrganizationManagement.Forms
{
    public partial class FormDirector : Form
    {
        private int organizationId;
        private string organizationName;

        public FormDirector(int orgId, string orgName)
        {
            InitializeComponent();
            this.organizationId = orgId;
            this.organizationName = orgName;
            this.Text = $"Director Management - {orgName}";
            lblOrgInfo.Text = $"Organization: {orgName} (ID: {orgId})";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
