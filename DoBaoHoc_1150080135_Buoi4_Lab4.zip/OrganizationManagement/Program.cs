using System;
using System.Windows.Forms;
using OrganizationManagement.Data;
using OrganizationManagement.Forms;

namespace OrganizationManagement
{
    static class Program
    {
        /// <summary>
        /// Entry point của ứng dụng
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Khởi tạo database
            try
            {
                DatabaseHelper.InitializeDatabase();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error initializing database: {ex.Message}", "Database Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Chạy form chính
            Application.Run(new FormOrganization());
        }
    }
}
