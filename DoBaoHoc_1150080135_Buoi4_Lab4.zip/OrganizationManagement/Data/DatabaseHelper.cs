using System;
using System.Data.SQLite;
using System.IO;
using OrganizationManagement.Data.Models;

namespace OrganizationManagement.Data
{
    /// <summary>
    /// Helper class để quản lý database SQLite
    /// </summary>
    public class DatabaseHelper
    {
        private static string dbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "OrganizationDB.db");
        private static string connectionString = $"Data Source={dbPath};Version=3;";

        /// <summary>
        /// Khởi tạo database và tạo bảng nếu chưa tồn tại
        /// </summary>
        public static void InitializeDatabase()
        {
            if (!File.Exists(dbPath))
            {
                SQLiteConnection.CreateFile(dbPath);
            }

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string createTableQuery = @"
                    CREATE TABLE IF NOT EXISTS ORGANIZATION (
                        OrgID INTEGER PRIMARY KEY AUTOINCREMENT,
                        OrgName VARCHAR(255) NOT NULL UNIQUE COLLATE NOCASE,
                        Address VARCHAR(255),
                        Phone VARCHAR(20),
                        Email VARCHAR(100),
                        CreatedDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                    )";

                using (var command = new SQLiteCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        /// Kiểm tra OrgName đã tồn tại trong database chưa (không phân biệt hoa/thường)
        /// </summary>
        public static bool IsOrgNameExists(string orgName)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM ORGANIZATION WHERE LOWER(OrgName) = LOWER(@OrgName)";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@OrgName", orgName);
                    int count = Convert.ToInt32(command.ExecuteScalar());
                    return count > 0;
                }
            }
        }

        /// <summary>
        /// Lưu Organization vào database
        /// </summary>
        public static int SaveOrganization(Organization org)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string query = @"
                    INSERT INTO ORGANIZATION (OrgName, Address, Phone, Email, CreatedDate)
                    VALUES (@OrgName, @Address, @Phone, @Email, @CreatedDate);
                    SELECT last_insert_rowid();";

                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@OrgName", org.OrgName);
                    command.Parameters.AddWithValue("@Address", org.Address ?? string.Empty);
                    command.Parameters.AddWithValue("@Phone", org.Phone ?? string.Empty);
                    command.Parameters.AddWithValue("@Email", org.Email ?? string.Empty);
                    command.Parameters.AddWithValue("@CreatedDate", org.CreatedDate);

                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        /// <summary>
        /// Lấy Organization theo ID
        /// </summary>
        public static Organization GetOrganizationById(int orgId)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM ORGANIZATION WHERE OrgID = @OrgID";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@OrgID", orgId);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Organization
                            {
                                OrgID = Convert.ToInt32(reader["OrgID"]),
                                OrgName = reader["OrgName"].ToString(),
                                Address = reader["Address"].ToString(),
                                Phone = reader["Phone"].ToString(),
                                Email = reader["Email"].ToString(),
                                CreatedDate = Convert.ToDateTime(reader["CreatedDate"])
                            };
                        }
                    }
                }
            }
            return null;
        }
    }
}
