using System;
using System.Text.RegularExpressions;

namespace OrganizationManagement.Validators
{
    /// <summary>
    /// Validator cho Organization với đầy đủ các ràng buộc theo yêu cầu
    /// </summary>
    public class OrganizationValidator
    {
        /// <summary>
        /// Validate OrgName
        /// - Không được để trống
        /// - Độ dài từ 3 đến 255 ký tự
        /// </summary>
        public static string ValidateOrgName(string orgName)
        {
            if (string.IsNullOrWhiteSpace(orgName))
            {
                return "Organization Name không được để trống";
            }

            if (orgName.Trim().Length < 3)
            {
                return "Organization Name phải có ít nhất 3 ký tự";
            }

            if (orgName.Length > 255)
            {
                return "Organization Name không được vượt quá 255 ký tự";
            }

            return string.Empty; // Hợp lệ
        }

        /// <summary>
        /// Validate Email (nếu nhập)
        /// - Đúng định dạng email
        /// </summary>
        public static string ValidateEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return string.Empty; // Email không bắt buộc
            }

            // Regex pattern cho email
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            
            if (!Regex.IsMatch(email, pattern))
            {
                return "Email không đúng định dạng";
            }

            return string.Empty; // Hợp lệ
        }

        /// <summary>
        /// Validate Phone (nếu nhập)
        /// - Chỉ chứa số
        /// - Độ dài từ 9-12 ký tự
        /// </summary>
        public static string ValidatePhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone))
            {
                return string.Empty; // Phone không bắt buộc
            }

            // Chỉ chấp nhận số
            if (!Regex.IsMatch(phone, @"^\d+$"))
            {
                return "Phone chỉ được chứa số";
            }

            if (phone.Length < 9)
            {
                return "Phone phải có ít nhất 9 ký tự";
            }

            if (phone.Length > 12)
            {
                return "Phone không được vượt quá 12 ký tự";
            }

            return string.Empty; // Hợp lệ
        }

        /// <summary>
        /// Validate tất cả các trường của Organization
        /// </summary>
        public static ValidationResult ValidateAll(string orgName, string address, string phone, string email)
        {
            var result = new ValidationResult { IsValid = true };

            // Validate OrgName
            string orgNameError = ValidateOrgName(orgName);
            if (!string.IsNullOrEmpty(orgNameError))
            {
                result.IsValid = false;
                result.OrgNameError = orgNameError;
            }

            // Validate Email
            string emailError = ValidateEmail(email);
            if (!string.IsNullOrEmpty(emailError))
            {
                result.IsValid = false;
                result.EmailError = emailError;
            }

            // Validate Phone
            string phoneError = ValidatePhone(phone);
            if (!string.IsNullOrEmpty(phoneError))
            {
                result.IsValid = false;
                result.PhoneError = phoneError;
            }

            return result;
        }
    }

    /// <summary>
    /// Kết quả validation
    /// </summary>
    public class ValidationResult
    {
        public bool IsValid { get; set; }
        public string OrgNameError { get; set; }
        public string AddressError { get; set; }
        public string PhoneError { get; set; }
        public string EmailError { get; set; }
    }
}
