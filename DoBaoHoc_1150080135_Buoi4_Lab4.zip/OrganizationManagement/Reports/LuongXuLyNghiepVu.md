# 5. LUỒNG XỬ LÝ NGHIỆP VỤ

## 5.1. Nút Lưu (Save)
Khi người dùng nhấn nút **Lưu**:

1. **Thực hiện validate dữ liệu**:
   - Kiểm tra **Tên Tổ chức**: Không được để trống, độ dài từ 3-255 ký tự.
   - Kiểm tra **Địa chỉ 1**: Không được để trống.
   - Kiểm tra **Số Điện thoại**: Không được để trống, chỉ chứa số, độ dài 9-12 ký tự.
   - Kiểm tra **Email**: Nếu nhập, phải đúng định dạng (có ký tự @ và domain).

2. **Nếu dữ liệu không hợp lệ**:
   - Hiển thị thông báo lỗi cụ thể qua hộp thoại (MessageBox).
   - Đưa con trỏ (Focus) về trường dữ liệu bị lỗi để người dùng sửa.
   - **Không** thực hiện lưu dữ liệu.

3. **Nếu Tên Tổ chức (OrgName) đã tồn tại trong CSDL**:
   - Hệ thống kiểm tra trong bảng `ORGANIZATION` (không phân biệt chữ hoa/chữ thường).
   - Nếu trùng, hiển thị thông báo: **"Tên Tổ chức đã tồn tại"** (Organisation Name already exists).
   - **Không** thực hiện lưu dữ liệu.

4. **Nếu dữ liệu hợp lệ**:
   - Hệ thống tự động ghép các trường địa chỉ (Địa chỉ 1, 2, 3, Thành phố, Quận, Mã bưu điện) thành một chuỗi địa chỉ đầy đủ.
   - Lưu thông tin Tổ chức vào CSDL SQLite.
   - Hiển thị thông báo: **"Lưu thành công!"** (Save successfully).
   - **Kích hoạt (Enable)** nút **Director** (nếu có trong thiết kế mở rộng) để cho phép quản lý nhân sự cấp cao.

---

## 5.2. Nút Director
*Lưu ý: Nút này thường được thiết kế để xuất hiện hoặc sáng lên sau khi tổ chức đã được khởi tạo thành công.*

- **Điều kiện**: Chỉ được phép nhấn sau khi đã thực hiện **Lưu** thành công bản ghi Tổ chức hiện tại.
- **Khi nhấn**:
  - Hệ thống lấy mã ID (`OrgID`) và Tên tổ chức vừa lưu.
  - Mở form **Quản lý Giám đốc** (Director Management).
  - Thông tin của Tổ chức vừa tạo được truyền sang form Director để làm ngữ cảnh quản lý.

---

## 5.3. Nút Quay lại (Back)
Khi người dùng nhấn nút **Quay lại**:

- **Đóng form hiện tại**: Giải phóng tài nguyên của form Thông tin Tổ chức.
- **Quay về màn hình trước đó**: Trở lại màn hình chính hoặc danh sách (nếu có).
- **Bảo mật dữ liệu**: Hệ thống **không lưu** bất kỳ thay đổi nào nếu người dùng chưa nhấn nút **Lưu** trước đó.
- Hiển thị cảnh báo xác nhận nếu có dữ liệu đang nhập dở (tùy chọn cấu hình).

---

**Trang 2** | *Tài liệu hướng dẫn nghiệp vụ - Project Organization Management*
