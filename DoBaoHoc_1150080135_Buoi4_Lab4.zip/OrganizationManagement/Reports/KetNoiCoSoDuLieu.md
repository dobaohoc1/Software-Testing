# 3. KẾT NỐI VÀ THAO TÁC VỚI CƠ SỞ DỮ LIỆU

## 3.1. Công nghệ sử dụng
- **Hệ quản trị CSDL**: SQLite 3 (Sử dụng thư viện `System.Data.SQLite`).
- **Lý do chọn**: Nhẹ, không cần cài đặt server phức tạp, phù hợp cho ứng dụng quản lý tổ chức quy mô vừa và nhỏ.
- **Connection String**: `Data Source=OrganizationDB.db;Version=3;` (File database được lưu cùng thư mục với tập tin thực thi `.exe`).

## 3.2. Cấu trúc bảng dữ liệu (Bảng ORGANIZATION)
Hệ thống sử dụng một bảng chính để lưu trữ thông tin:

| Tên cột | Kiểu dữ liệu | Mô tả |
| :--- | :--- | :--- |
| **OrgID** | INTEGER | Khóa chính, tự động tăng (Primary Key, AutoIncrement). |
| **OrgName** | VARCHAR(255) | Tên tổ chức (Bắt buộc, Duy nhất, Không phân biệt hoa thường). |
| **Address** | VARCHAR(255) | Địa chỉ đầy đủ (Ghép từ các trường nhập liệu địa chỉ). |
| **Phone** | VARCHAR(20) | Số điện thoại liên lạc. |
| **Email** | VARCHAR(100) | Địa chỉ thư điện tử. |
| **CreatedDate** | DATETIME | Thời gian tạo bản ghi (Mặc định lấy giờ hệ thống). |

## 3.3. Các thao tác chính (DatabaseHelper)

### 3.3.1. Khởi tạo cơ sở dữ liệu (InitializeDatabase)
- **Mục đích**: Tự động kiểm tra và tạo file database `OrganizationDB.db` khi ứng dụng khởi chạy lần đầu.
- **Logic**: Sử dụng câu lệnh `CREATE TABLE IF NOT EXISTS` để đảm bảo cấu trúc bảng luôn sẵn sàng mà không làm mất dữ liệu cũ.

### 3.3.2. Kiểm tra trùng tên (IsOrgNameExists)
- **Mục đích**: Đảm bảo tính duy nhất của Tên Tổ chức trước khi lưu.
- **Logic**: Thực hiện truy vấn `SELECT COUNT(*)` với điều kiện `LOWER(OrgName) = LOWER(@OrgName)` để kiểm tra sự tồn tại của tên (không phân biệt hoa thường).

### 3.3.3. Lưu dữ liệu (SaveOrganization)
- **Mục đích**: Thêm mới một tổ chức vào hệ thống.
- **Logic**: 
    - Sử dụng `SQL Parameter` để chống tấn công SQL Injection.
    - Sau khi `INSERT`, sử dụng lệnh `SELECT last_insert_rowid()` để lấy lại ID vừa tạo, phục vụ cho việc truyền dữ liệu sang form Director.

### 3.3.4. Truy vấn thông tin (GetOrganizationById)
- **Mục đích**: Lấy dữ liệu chi tiết của một tổ chức dựa trên ID.
- **Logic**: Trả về một đối tượng (Model) `Organization` chứa đầy đủ các thuộc tính để hiển thị lên giao diện hoặc xử lý nghiệp vụ tiếp theo.

---
**Trang 3** | *Tài liệu kỹ thuật - Project Organization Management*
