# BÁO CÁO TỔNG KẾT DỰ ÁN KIỂM THỬ PHẦN MỀM (JUNIT)

**Người thực hiện:** Đỗ Bảo Học  
**Ngày lập báo cáo:** 27/01/2026  
**Dự án:** projectjava (Lab JUnit Testing)

---

## 1. Giới thiệu
Dự án tập trung vào việc áp dụng các kỹ thuật kiểm thử đơn vị (Unit Testing) sử dụng framework JUnit trong ngôn ngữ lập trình Java. Mục tiêu của dự án bao gồm:
*   Xây dựng và kiểm thử các hàm logic cơ bản (Giai thừa, Tổng).
*   Sử dụng các tính năng nâng cao của JUnit như Test Suite, Test Fixtures và Annotations.
*   Xây dựng ứng dụng thực tế (Tính tiền bệnh nhân, Form đăng ký khách hàng) và thực hiện kiểm thử dựa trên đặc tả yêu cầu chi tiết.

## 2. Môi trường kiểm thử
*   **Ngôn ngữ lập trình:** Java (JDK 25)
*   **Framework kiểm thử:** JUnit 4 & JUnit 5 (Jupiter/Vintage)
*   **Công cụ quản lý dự án:** Apache Maven 3.9.12
*   **Hệ điều hành:** Windows
*   **IDE:** Visual Studio Code / IntelliJ IDEA

## 3. Danh sách Test Case
Dự án được chia thành 5 nhóm kiểm thử chính với tổng cộng 46 test cases:

### 3.1. Bài 1: Kiểm thử Calculator cơ bản (7 Test Cases)
*   Kiểm tra tính giai thừa số dương, số 0 và xử lý số âm.
*   Kiểm tra tính tổng hai số nguyên.
*   Kiểm tra biến đếm `calls` để xác nhận số lần gọi hàm.

### 3.2. Bài 2: JUnit Test Suite (5 Test Cases)
*   Tổ chức kiểm thử theo nhóm (Suite) để chạy đồng thời nhiều lớp kiểm thử (`Suite1Test`, `Suite2Test`).

### 3.3. Bài 3: JUnit Annotations (9 Test Cases)
*   Kiểm thử vòng đời của một Test Case: `@BeforeClass`, `@AfterClass`, `@Before`, `@After`.
*   Kiểm tra các đặc tính: `@Test(timeout)`, `@Test(expected)`, `@Ignore`.

### 3.4. Bài 4: Tính tiền bệnh nhân (10 Test Cases)
*   Kiểm thử logic tính tiền dựa trên phân vùng tương đương: Nam/Nữ (18-35, 36-50, 51-145) và Trẻ em (0-17).

### 3.5. Bài 5: Form Đăng ký khách hàng (15 Test Cases)
*   Kiểm thử 10 ràng buộc dữ liệu: Mã KH (duy nhất, 6-10 ký tự), Email (định dạng, duy nhất), SĐT (bắt đầu bằng 0, 10-12 số), Tuổi (>=18), Mật khẩu khớp nhau, v.v.

## 4. Tổng kết kết quả kiểm thử
Dựa trên việc thực thi lệnh `mvn test` và `TestRunner`:

| Nội dung | Tổng số | Thành công | Thất bại | Bị bỏ qua (Skipped) |
| :--- | :---: | :---: | :---: | :---: |
| **Tổng số Test Case** | **46** | **45** | **0** | **1** |
| **Tỷ lệ %** | **100%** | **97.8%** | **0%** | **2.2%** |

*   **Kết luận:** Dự án đạt yêu cầu về mặt logic. Tất cả các chức năng quan trọng đều hoạt động đúng theo đặc tả. Trường hợp bị bỏ qua (Skipped) nằm trong kế hoạch (sử dụng `@Ignore` để minh họa tính năng).

## 5. Nhận xét và đề xuất cải tiến
### 5.1. Nhận xét
*   **Ưu điểm:** Mã nguồn được tổ chức theo cấu trúc Maven chuẩn, dễ dàng bảo trì và mở rộng. Các thông báo lỗi trong Form đăng ký rõ ràng, thân thiện với người dùng.
*   **Độ bao phủ:** Test cases bao phủ được các trường hợp biên (Boundary Value) và các trường hợp ngoại lệ (Exception Handling).

### 5.2. Đề xuất cải tiến
*   **Tự động hóa:** Tích hợp kiểm thử giao diện (UI Testing) bằng các công cụ như Selenium hoặc AssertJ Swing để thay thế việc kiểm thử thủ công trên Form.
*   **Dữ liệu:** Kết nối với cơ sở dữ liệu thực tế (như MySQL hoặc SQLite) để kiểm tra tính duy nhất của Mã KH và Email một cách chính xác hơn thay vì dùng `HashSet` giả lập.
*   **Báo cáo:** Sử dụng thêm plugin `Maven Surefire Report` để xuất báo cáo dưới dạng HTML chuyên nghiệp hơn.
