package com.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PatientCalculatorUI extends JFrame {
    private JRadioButton maleBtn, femaleBtn, childBtn;
    private JTextField ageField, paymentField;
    private JButton calculateBtn;
    private PatientCalculator calculator;

    public PatientCalculatorUI() {
        calculator = new PatientCalculator();
        setTitle("Calculate the Payment for the Patient");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 10, 10));

        // Gender selection
        maleBtn = new JRadioButton("Male", true);
        femaleBtn = new JRadioButton("Female");
        childBtn = new JRadioButton("Child (0 - 17 years)");
        ButtonGroup group = new ButtonGroup();
        group.add(maleBtn);
        group.add(femaleBtn);
        group.add(childBtn);

        add(maleBtn);
        add(femaleBtn);
        add(childBtn);
        add(new JLabel("")); // Placeholder

        // Age input
        add(new JLabel("Age (Years):"));
        ageField = new JTextField();
        add(ageField);

        // Calculate button
        calculateBtn = new JButton("Calculate");
        add(calculateBtn);
        add(new JLabel("")); // Placeholder

        // Result display
        add(new JLabel("Payment is:"));
        paymentField = new JTextField();
        paymentField.setEditable(false);
        add(paymentField);

        calculateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int age = Integer.parseInt(ageField.getText());
                    PatientCalculator.Gender gender = PatientCalculator.Gender.MALE;
                    if (femaleBtn.isSelected()) gender = PatientCalculator.Gender.FEMALE;
                    if (childBtn.isSelected()) gender = PatientCalculator.Gender.CHILD;

                    int payment = calculator.calculatePayment(gender, age);
                    paymentField.setText(payment + " euro");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Vui lòng nhập tuổi là số nguyên!");
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new PatientCalculatorUI().setVisible(true);
        });
    }
}
