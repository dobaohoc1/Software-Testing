package com.example;

public class Calculator {
    private int calls = 0;

    public long factorial(int n) {
        calls++;
        if (n < 0) {
            throw new IllegalArgumentException("Số nguyên phải không âm");
        }
        if (n == 0 || n == 1) {
            return 1;
        }
        long result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }

    public int sum(int a, int b) {
        calls++;
        return a + b;
    }

    public int getCalls() {
        return calls;
    }
}
