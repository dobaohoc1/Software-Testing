package com.example;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class RegistrationFormUI extends JFrame {
    private JTextField txtId, txtName, txtEmail, txtPhone, txtDob;
    private JTextArea txtAddress;
    private JPasswordField txtPassword, txtConfirmPassword;
    private JRadioButton rbMale, rbFemale, rbOther;
    private JCheckBox cbTerms;
    private JButton btnRegister, btnReset;

    public RegistrationFormUI() {
        setTitle("ĐĂNG KÝ TÀI KHOẢN KHÁCH HÀNG");
        setSize(600, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Title
        JLabel lblTitle = new JLabel("ĐĂNG KÝ TÀI KHOẢN KHÁCH HÀNG", JLabel.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        mainPanel.add(lblTitle, gbc);

        gbc.gridwidth = 1;
        int row = 1;

        // Mã Khách Hàng
        addLabelAndField(mainPanel, gbc, "Mã Khách Hàng *", txtId = new JTextField(20), row++);
        // Họ và Tên
        addLabelAndField(mainPanel, gbc, "Họ và Tên *", txtName = new JTextField(20), row++);
        // Email
        addLabelAndField(mainPanel, gbc, "Email *", txtEmail = new JTextField(20), row++);
        // Số điện thoại
        addLabelAndField(mainPanel, gbc, "Số điện thoại *", txtPhone = new JTextField(20), row++);
        
        // Địa chỉ
        gbc.gridx = 0; gbc.gridy = row;
        mainPanel.add(new JLabel("Địa chỉ *"), gbc);
        txtAddress = new JTextArea(3, 20);
        txtAddress.setLineWrap(true);
        gbc.gridx = 1;
        mainPanel.add(new JScrollPane(txtAddress), gbc);
        row++;

        // Mật khẩu
        addLabelAndField(mainPanel, gbc, "Mật khẩu *", txtPassword = new JPasswordField(20), row++);
        // Xác nhận mật khẩu
        addLabelAndField(mainPanel, gbc, "Xác nhận Mật khẩu *", txtConfirmPassword = new JPasswordField(20), row++);
        // Ngày sinh
        addLabelAndField(mainPanel, gbc, "Ngày sinh (dd/mm/yyyy)", txtDob = new JTextField(20), row++);

        // Giới tính
        gbc.gridx = 0; gbc.gridy = row;
        mainPanel.add(new JLabel("Giới tính"), gbc);
        JPanel pnlGender = new JPanel(new FlowLayout(FlowLayout.LEFT));
        rbMale = new JRadioButton("Nam");
        rbFemale = new JRadioButton("Nữ");
        rbOther = new JRadioButton("Khác");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(rbMale); genderGroup.add(rbFemale); genderGroup.add(rbOther);
        pnlGender.add(rbMale); pnlGender.add(rbFemale); pnlGender.add(rbOther);
        gbc.gridx = 1;
        mainPanel.add(pnlGender, gbc);
        row++;

        // Điều khoản
        cbTerms = new JCheckBox("Tôi đồng ý với các điều khoản dịch vụ *");
        gbc.gridx = 1; gbc.gridy = row++;
        mainPanel.add(cbTerms, gbc);

        // Buttons
        JPanel pnlButtons = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        btnRegister = new JButton("Đăng ký");
        btnRegister.setBackground(new Color(0, 123, 255));
        btnRegister.setForeground(Color.WHITE);
        btnReset = new JButton("Nhập lại");
        btnReset.setBackground(new Color(108, 117, 125));
        btnReset.setForeground(Color.WHITE);
        pnlButtons.add(btnRegister);
        pnlButtons.add(btnReset);
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        mainPanel.add(pnlButtons, gbc);

        add(new JScrollPane(mainPanel));

        // Action Listeners
        btnRegister.addActionListener(e -> handleRegister());
        btnReset.addActionListener(e -> handleReset());
    }

    private void addLabelAndField(JPanel panel, GridBagConstraints gbc, String label, JComponent field, int row) {
        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        panel.add(field, gbc);
    }

    private void handleRegister() {
        String id = txtId.getText().trim();
        String name = txtName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        String address = txtAddress.getText().trim();
        String password = new String(txtPassword.getPassword());
        String confirmPassword = new String(txtConfirmPassword.getPassword());
        boolean terms = cbTerms.isSelected();

        LocalDate dob = null;
        if (!txtDob.getText().trim().isEmpty()) {
            try {
                dob = LocalDate.parse(txtDob.getText().trim(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            } catch (DateTimeParseException e) {
                JOptionPane.showMessageDialog(this, "Ngày sinh không đúng định dạng dd/mm/yyyy", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        String error = RegistrationValidator.validate(id, name, email, phone, address, password, confirmPassword, dob, terms);
        if (error != null) {
            JOptionPane.showMessageDialog(this, error, "Lỗi nhập liệu", JOptionPane.ERROR_MESSAGE);
        } else {
            RegistrationValidator.saveUser(id, email);
            JOptionPane.showMessageDialog(this, "Đăng ký tài khoản thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void handleReset() {
        txtId.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtAddress.setText("");
        txtPassword.setText("");
        txtConfirmPassword.setText("");
        txtDob.setText("");
        rbMale.setSelected(false);
        rbFemale.setSelected(false);
        rbOther.setSelected(false);
        cbTerms.setSelected(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RegistrationFormUI().setVisible(true));
    }
}
