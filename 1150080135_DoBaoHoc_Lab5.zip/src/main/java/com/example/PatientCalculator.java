package com.example;

public class PatientCalculator {
    public enum Gender {
        MALE, FEMALE, CHILD
    }

    public int calculatePayment(Gender gender, int age) {
        if (age < 0 || age > 145) {
            throw new IllegalArgumentException("Tuổi không hợp lệ (0 - 145)");
        }

        // Trường hợp trẻ em (0 - 17 tuổi)
        if (age <= 17) {
            return 50;
        }

        // Trường hợp người lớn
        if (gender == Gender.MALE) {
            if (age <= 35) return 100;
            if (age <= 50) return 120;
            return 140;
        } else if (gender == Gender.FEMALE) {
            if (age <= 35) return 80;
            if (age <= 50) return 110;
            return 140;
        }

        return 50; // Mặc định cho Child checkbox nếu có
    }
}
