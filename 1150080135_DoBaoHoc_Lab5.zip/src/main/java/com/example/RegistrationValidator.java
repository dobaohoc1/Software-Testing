package com.example;

import java.time.LocalDate;
import java.time.Period;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

public class RegistrationValidator {
    // Giả lập database để kiểm tra tính duy nhất
    private static Set<String> existingIds = new HashSet<>();
    private static Set<String> existingEmails = new HashSet<>();

    public static String validate(String id, String name, String email, String phone, String address, 
                                String password, String confirmPassword, LocalDate dob, boolean termsAccepted) {
        
        // 1. Mã Khách Hàng
        if (id == null || id.isEmpty()) return "Mã khách hàng là bắt buộc.";
        if (id.length() < 6 || id.length() > 10) return "Mã khách hàng phải từ 6 đến 10 ký tự.";
        if (!Pattern.matches("^[a-zA-Z0-9]+$", id)) return "Mã khách hàng chỉ được chứa chữ cái và số.";
        if (existingIds.contains(id)) return "Mã khách hàng đã tồn tại.";

        // 2. Họ và Tên
        if (name == null || name.isEmpty()) return "Họ và tên là bắt buộc.";
        if (name.length() < 5 || name.length() > 50) return "Họ và tên phải từ 5 đến 50 ký tự.";

        // 3. Email
        if (email == null || email.isEmpty()) return "Email là bắt buộc.";
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        if (!Pattern.matches(emailRegex, email)) return "Email không đúng định dạng.";
        if (existingEmails.contains(email)) return "Email đã được sử dụng.";

        // 4. Số điện thoại
        if (phone == null || phone.isEmpty()) return "Số điện thoại là bắt buộc.";
        if (!Pattern.matches("^0[0-9]{9,11}$", phone)) return "Số điện thoại phải bắt đầu bằng số 0 và có 10-12 chữ số.";

        // 5. Địa chỉ
        if (address == null || address.isEmpty()) return "Địa chỉ là bắt buộc.";
        if (address.length() > 255) return "Địa chỉ không được quá 255 ký tự.";

        // 6. Mật khẩu
        if (password == null || password.isEmpty()) return "Mật khẩu là bắt buộc.";
        if (password.length() < 8) return "Mật khẩu phải có ít nhất 8 ký tự.";

        // 7. Xác nhận mật khẩu
        if (confirmPassword == null || confirmPassword.isEmpty()) return "Xác nhận mật khẩu là bắt buộc.";
        if (!password.equals(confirmPassword)) return "Mật khẩu xác nhận không khớp.";

        // 8. Ngày sinh (Nếu có)
        if (dob != null) {
            if (Period.between(dob, LocalDate.now()).getYears() < 18) {
                return "Người dùng phải đủ 18 tuổi.";
            }
        }

        // 10. Điều khoản
        if (!termsAccepted) return "Bạn phải đồng ý với các điều khoản dịch vụ.";

        return null; // Hợp lệ
    }

    public static void saveUser(String id, String email) {
        existingIds.add(id);
        existingEmails.add(email);
    }

    public static void clearData() {
        existingIds.clear();
        existingEmails.clear();
    }
}
