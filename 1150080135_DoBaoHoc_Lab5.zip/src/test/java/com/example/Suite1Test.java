package com.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class Suite1Test {
    Calculator calculator = new Calculator();

    @Test
    public void testFactorial() {
        System.out.println("Running SuiteTest1: testFactorial");
        assertEquals(120, calculator.factorial(5));
        assertEquals(1, calculator.factorial(0));
    }
}
