package com.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CalculatorTest {
    private Calculator calculator;

    @BeforeEach
    public void setUp() {
        // Test fixture: khởi tạo đối tượng trước mỗi bài kiểm tra
        calculator = new Calculator();
    }

    @Test
    public void calls() {
        // Ban đầu calls phải bằng 0
        assertEquals(0, calculator.getCalls(), "Biến calls phải bằng 0 khi mới khởi tạo");
        
        calculator.sum(1, 2);
        assertEquals(1, calculator.getCalls(), "Biến calls phải bằng 1 sau khi gọi 1 phương thức");
        
        calculator.factorial(5);
        assertEquals(2, calculator.getCalls(), "Biến calls phải bằng 2 sau khi gọi 2 phương thức");
    }

    @Test
    public void factorial() {
        assertEquals(1, calculator.factorial(0), "Giai thừa của 0 phải là 1");
        assertEquals(1, calculator.factorial(1), "Giai thừa của 1 phải là 1");
        assertEquals(120, calculator.factorial(5), "Giai thừa của 5 phải là 120");
    }

    @Test
    public void factorialNegative() {
        // Kiểm tra trường hợp số âm phải ném ra ngoại lệ
        assertThrows(IllegalArgumentException.class, () -> {
            calculator.factorial(-1);
        }, "Phải ném ra IllegalArgumentException khi tính giai thừa số âm");
    }

    @Test
    public void todo() {
        // Kiểm tra phương thức tính tổng
        assertEquals(5, calculator.sum(2, 3), "Tổng của 2 và 3 phải là 5");
        assertEquals(-1, calculator.sum(2, -3), "Tổng của 2 và -3 phải là -1");
        assertEquals(0, calculator.sum(0, 0), "Tổng của 0 và 0 phải là 0");
    }
}
