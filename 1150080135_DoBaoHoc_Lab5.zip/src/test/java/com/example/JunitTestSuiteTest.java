package com.example;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    Suite1Test.class,
    Suite2Test.class
})
public class JunitTestSuiteTest {
    // Lớp này không cần nội dung, nó chỉ dùng để gom nhóm các test class lại
}
