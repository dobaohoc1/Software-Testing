package com.example;

import org.junit.*;
import static org.junit.Assert.*;

public class AnnotationTest {
    private Calculator calculator;

    // Chạy duy nhất một lần trước khi bất kỳ test case nào bắt đầu
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        System.out.println("--- @BeforeClass: Khởi tạo tài nguyên dùng chung cho cả lớp (ví dụ: Kết nối DB) ---");
    }

    // Chạy duy nhất một lần sau khi tất cả các test case đã kết thúc
    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        System.out.println("--- @AfterClass: Giải phóng tài nguyên dùng chung ---");
    }

    // Chạy trước mỗi phương thức @Test
    @Before
    public void setUp() {
        System.out.println("@Before: Khởi tạo đối tượng Calculator mới");
        calculator = new Calculator();
    }

    // Chạy sau mỗi phương thức @Test
    @After
    public void tearDown() {
        System.out.println("@After: Dọn dẹp sau khi test xong");
        calculator = null;
    }

    @Test
    public void testSum() {
        System.out.println("@Test: Đang kiểm thử hàm sum");
        assertEquals(10, calculator.sum(5, 5));
    }

    @Test
    public void testFactorial() {
        System.out.println("@Test: Đang kiểm thử hàm factorial");
        assertEquals(1, calculator.factorial(0));
    }

    // Phương thức này sẽ bị bỏ qua khi chạy test
    @Ignore
    @Test
    public void testIgnored() {
        System.out.println("@Ignore: Phương thức này sẽ không bao giờ được in ra");
    }

    // Kiểm tra thời gian thực thi (timeout)
    @Test(timeout = 1000)
    public void testTimeout() {
        System.out.println("@Test(timeout): Kiểm tra thời gian phản hồi");
        calculator.sum(1, 1);
    }
}
