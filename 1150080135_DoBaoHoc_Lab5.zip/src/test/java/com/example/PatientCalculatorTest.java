package com.example;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class PatientCalculatorTest {
    private PatientCalculator calculator;

    @Before
    public void setUp() {
        calculator = new PatientCalculator();
    }

    @Test
    public void testChild() {
        // Trẻ em 0-17 tuổi luôn là 50 euro
        assertEquals(50, calculator.calculatePayment(PatientCalculator.Gender.MALE, 10));
        assertEquals(50, calculator.calculatePayment(PatientCalculator.Gender.FEMALE, 17));
        assertEquals(50, calculator.calculatePayment(PatientCalculator.Gender.CHILD, 0));
    }

    @Test
    public void testMale() {
        // Nam 18-35: 100
        assertEquals(100, calculator.calculatePayment(PatientCalculator.Gender.MALE, 20));
        assertEquals(100, calculator.calculatePayment(PatientCalculator.Gender.MALE, 35));

        // Nam 36-50: 120
        assertEquals(120, calculator.calculatePayment(PatientCalculator.Gender.MALE, 40));
        assertEquals(120, calculator.calculatePayment(PatientCalculator.Gender.MALE, 50));

        // Nam 51-145: 140
        assertEquals(140, calculator.calculatePayment(PatientCalculator.Gender.MALE, 60));
        assertEquals(140, calculator.calculatePayment(PatientCalculator.Gender.MALE, 145));
    }

    @Test
    public void testFemale() {
        // Nữ 18-35: 80
        assertEquals(80, calculator.calculatePayment(PatientCalculator.Gender.FEMALE, 25));
        assertEquals(80, calculator.calculatePayment(PatientCalculator.Gender.FEMALE, 35));

        // Nữ 36-50: 110
        assertEquals(110, calculator.calculatePayment(PatientCalculator.Gender.FEMALE, 45));
        assertEquals(110, calculator.calculatePayment(PatientCalculator.Gender.FEMALE, 50));

        // Nữ 51-145: 140
        assertEquals(140, calculator.calculatePayment(PatientCalculator.Gender.FEMALE, 55));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidAgeNegative() {
        calculator.calculatePayment(PatientCalculator.Gender.MALE, -1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidAgeTooOld() {
        calculator.calculatePayment(PatientCalculator.Gender.MALE, 150);
    }
}
