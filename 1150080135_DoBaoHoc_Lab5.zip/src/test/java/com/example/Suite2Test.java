package com.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class Suite2Test {
    Calculator calculator = new Calculator();

    @Test
    public void testSum() {
        System.out.println("Running SuiteTest2: testSum");
        assertEquals(10, calculator.sum(7, 3));
        assertEquals(0, calculator.sum(0, 0));
    }
}
