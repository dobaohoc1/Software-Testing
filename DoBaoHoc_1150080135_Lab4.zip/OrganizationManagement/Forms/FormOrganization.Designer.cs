namespace OrganizationManagement.Forms
{
    partial class FormOrganization
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.GroupBox grpOrgDetails;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabDetails1;
        private System.Windows.Forms.TabPage tabDetails2;
        private System.Windows.Forms.TabPage tabDetails3;
        private System.Windows.Forms.Label lblOrgName;
        private System.Windows.Forms.TextBox txtOrgName;
        private System.Windows.Forms.Label lblOrgShortDesc;
        private System.Windows.Forms.TextBox txtOrgShortDesc;
        private System.Windows.Forms.Label lblLeadContact;
        private System.Windows.Forms.TextBox txtLeadContact;
        private System.Windows.Forms.Button btnLeadLookup;
        private System.Windows.Forms.Label lblAddressLine1;
        private System.Windows.Forms.TextBox txtAddressLine1;
        private System.Windows.Forms.Label lblAddressLine2;
        private System.Windows.Forms.TextBox txtAddressLine2;
        private System.Windows.Forms.Label lblAddressLine3;
        private System.Windows.Forms.TextBox txtAddressLine3;
        private System.Windows.Forms.Label lblPostcode;
        private System.Windows.Forms.TextBox txtPostcode;
        private System.Windows.Forms.Button btnPostcodeLookup;
        private System.Windows.Forms.Label lblCityTown;
        private System.Windows.Forms.TextBox txtCityTown;
        private System.Windows.Forms.Label lblCounty;
        private System.Windows.Forms.TextBox txtCounty;
        private System.Windows.Forms.CheckBox chkPreferredOrg;
        private System.Windows.Forms.CheckBox chkExpressionOfInterest;
        private System.Windows.Forms.Label lblTypeOfBusiness;
        private System.Windows.Forms.TextBox txtTypeOfBusiness;
        private System.Windows.Forms.Button btnBusinessLookup;
        private System.Windows.Forms.Label lblSICCode;
        private System.Windows.Forms.TextBox txtSICCode;
        private System.Windows.Forms.Label lblOrgFullDesc;
        private System.Windows.Forms.TextBox txtOrgFullDesc;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.Label lblFax;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblWebAddress;
        private System.Windows.Forms.TextBox txtWebAddress;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnBack;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.grpOrgDetails = new System.Windows.Forms.GroupBox();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabDetails1 = new System.Windows.Forms.TabPage();
            this.tabDetails2 = new System.Windows.Forms.TabPage();
            this.tabDetails3 = new System.Windows.Forms.TabPage();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            
            // Tab Details 1 controls
            this.lblOrgName = new System.Windows.Forms.Label();
            this.txtOrgName = new System.Windows.Forms.TextBox();
            this.lblOrgShortDesc = new System.Windows.Forms.Label();
            this.txtOrgShortDesc = new System.Windows.Forms.TextBox();
            this.lblLeadContact = new System.Windows.Forms.Label();
            this.txtLeadContact = new System.Windows.Forms.TextBox();
            this.btnLeadLookup = new System.Windows.Forms.Button();
            this.lblAddressLine1 = new System.Windows.Forms.Label();
            this.txtAddressLine1 = new System.Windows.Forms.TextBox();
            this.lblAddressLine2 = new System.Windows.Forms.Label();
            this.txtAddressLine2 = new System.Windows.Forms.TextBox();
            this.lblAddressLine3 = new System.Windows.Forms.Label();
            this.txtAddressLine3 = new System.Windows.Forms.TextBox();
            this.lblPostcode = new System.Windows.Forms.Label();
            this.txtPostcode = new System.Windows.Forms.TextBox();
            this.btnPostcodeLookup = new System.Windows.Forms.Button();
            this.lblCityTown = new System.Windows.Forms.Label();
            this.txtCityTown = new System.Windows.Forms.TextBox();
            this.lblCounty = new System.Windows.Forms.Label();
            this.txtCounty = new System.Windows.Forms.TextBox();
            this.chkPreferredOrg = new System.Windows.Forms.CheckBox();
            this.chkExpressionOfInterest = new System.Windows.Forms.CheckBox();
            this.lblTypeOfBusiness = new System.Windows.Forms.Label();
            this.txtTypeOfBusiness = new System.Windows.Forms.TextBox();
            this.btnBusinessLookup = new System.Windows.Forms.Button();
            this.lblSICCode = new System.Windows.Forms.Label();
            this.txtSICCode = new System.Windows.Forms.TextBox();
            this.lblOrgFullDesc = new System.Windows.Forms.Label();
            this.txtOrgFullDesc = new System.Windows.Forms.TextBox();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.lblFax = new System.Windows.Forms.Label();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblWebAddress = new System.Windows.Forms.Label();
            this.txtWebAddress = new System.Windows.Forms.TextBox();
            
            this.grpOrgDetails.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabDetails1.SuspendLayout();
            this.SuspendLayout();
            
            // grpOrgDetails
            this.grpOrgDetails.Controls.Add(this.tabControl);
            this.grpOrgDetails.Controls.Add(this.btnSave);
            this.grpOrgDetails.Controls.Add(this.btnBack);
            this.grpOrgDetails.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.grpOrgDetails.ForeColor = System.Drawing.Color.Green;
            this.grpOrgDetails.Location = new System.Drawing.Point(10, 10);
            this.grpOrgDetails.Name = "grpOrgDetails";
            this.grpOrgDetails.Size = new System.Drawing.Size(780, 480);
            this.grpOrgDetails.TabIndex = 0;
            this.grpOrgDetails.TabStop = false;
            this.grpOrgDetails.Text = "Thông tin Tổ chức";
            
            // tabControl
            this.tabControl.Controls.Add(this.tabDetails1);
            this.tabControl.Controls.Add(this.tabDetails2);
            this.tabControl.Controls.Add(this.tabDetails3);
            this.tabControl.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.tabControl.Location = new System.Drawing.Point(10, 20);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(760, 420);
            this.tabControl.TabIndex = 0;
            
            // tabDetails1
            this.tabDetails1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabDetails1.Controls.Add(this.lblOrgName);
            this.tabDetails1.Controls.Add(this.txtOrgName);
            this.tabDetails1.Controls.Add(this.chkPreferredOrg);
            this.tabDetails1.Controls.Add(this.lblOrgShortDesc);
            this.tabDetails1.Controls.Add(this.txtOrgShortDesc);
            this.tabDetails1.Controls.Add(this.chkExpressionOfInterest);
            this.tabDetails1.Controls.Add(this.lblLeadContact);
            this.tabDetails1.Controls.Add(this.txtLeadContact);
            this.tabDetails1.Controls.Add(this.btnLeadLookup);
            this.tabDetails1.Controls.Add(this.lblTypeOfBusiness);
            this.tabDetails1.Controls.Add(this.txtTypeOfBusiness);
            this.tabDetails1.Controls.Add(this.btnBusinessLookup);
            this.tabDetails1.Controls.Add(this.lblAddressLine1);
            this.tabDetails1.Controls.Add(this.txtAddressLine1);
            this.tabDetails1.Controls.Add(this.lblSICCode);
            this.tabDetails1.Controls.Add(this.txtSICCode);
            this.tabDetails1.Controls.Add(this.lblAddressLine2);
            this.tabDetails1.Controls.Add(this.txtAddressLine2);
            this.tabDetails1.Controls.Add(this.lblOrgFullDesc);
            this.tabDetails1.Controls.Add(this.txtOrgFullDesc);
            this.tabDetails1.Controls.Add(this.lblAddressLine3);
            this.tabDetails1.Controls.Add(this.txtAddressLine3);
            this.tabDetails1.Controls.Add(this.lblPhoneNumber);
            this.tabDetails1.Controls.Add(this.txtPhoneNumber);
            this.tabDetails1.Controls.Add(this.lblPostcode);
            this.tabDetails1.Controls.Add(this.txtPostcode);
            this.tabDetails1.Controls.Add(this.btnPostcodeLookup);
            this.tabDetails1.Controls.Add(this.lblFax);
            this.tabDetails1.Controls.Add(this.txtFax);
            this.tabDetails1.Controls.Add(this.lblCityTown);
            this.tabDetails1.Controls.Add(this.txtCityTown);
            this.tabDetails1.Controls.Add(this.lblEmail);
            this.tabDetails1.Controls.Add(this.txtEmail);
            this.tabDetails1.Controls.Add(this.lblCounty);
            this.tabDetails1.Controls.Add(this.txtCounty);
            this.tabDetails1.Controls.Add(this.lblWebAddress);
            this.tabDetails1.Controls.Add(this.txtWebAddress);
            this.tabDetails1.Location = new System.Drawing.Point(4, 22);
            this.tabDetails1.Name = "tabDetails1";
            this.tabDetails1.Padding = new System.Windows.Forms.Padding(3);
            this.tabDetails1.Size = new System.Drawing.Size(752, 394);
            this.tabDetails1.TabIndex = 0;
            this.tabDetails1.Text = "Chi tiết 1";
            
            // Column 1 - Left side
            int leftX = 15;
            int rightX = 400;
            int labelWidth = 120;
            int textBoxWidth = 240;
            int rowHeight = 30;
            int startY = 15;
            
            // Organisation Name *
            this.lblOrgName.Location = new System.Drawing.Point(leftX, startY);
            this.lblOrgName.Size = new System.Drawing.Size(labelWidth, 20);
            this.lblOrgName.Text = "Tên Tổ chức *";
            this.lblOrgName.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtOrgName.Location = new System.Drawing.Point(leftX + labelWidth, startY - 2);
            this.txtOrgName.Size = new System.Drawing.Size(textBoxWidth, 21);
            this.txtOrgName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            // Preferred Organisation (checkbox)
            this.chkPreferredOrg.Location = new System.Drawing.Point(rightX, startY);
            this.chkPreferredOrg.Size = new System.Drawing.Size(150, 20);
            this.chkPreferredOrg.Text = "Tổ chức Ưu tiên";
            this.chkPreferredOrg.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            // Organisation Short Description
            this.lblOrgShortDesc.Location = new System.Drawing.Point(leftX, startY + rowHeight);
            this.lblOrgShortDesc.Size = new System.Drawing.Size(labelWidth, 35);
            this.lblOrgShortDesc.Text = "Mô tả Tổ chức\r\n(ngắn gọn)";
            this.lblOrgShortDesc.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtOrgShortDesc.Location = new System.Drawing.Point(leftX + labelWidth, startY + rowHeight - 2);
            this.txtOrgShortDesc.Size = new System.Drawing.Size(textBoxWidth, 21);
            this.txtOrgShortDesc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            // Expression of Interest (checkbox)
            this.chkExpressionOfInterest.Location = new System.Drawing.Point(rightX, startY + rowHeight);
            this.chkExpressionOfInterest.Size = new System.Drawing.Size(150, 20);
            this.chkExpressionOfInterest.Text = "Quan tâm Hợp tác";
            this.chkExpressionOfInterest.Checked = true;
            this.chkExpressionOfInterest.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            // Lead Contact
            this.lblLeadContact.Location = new System.Drawing.Point(leftX, startY + rowHeight * 2);
            this.lblLeadContact.Size = new System.Drawing.Size(labelWidth, 20);
            this.lblLeadContact.Text = "Người Liên hệ";
            this.lblLeadContact.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtLeadContact.Location = new System.Drawing.Point(leftX + labelWidth, startY + rowHeight * 2 - 2);
            this.txtLeadContact.Size = new System.Drawing.Size(textBoxWidth - 60, 21);
            this.txtLeadContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            this.btnLeadLookup.Location = new System.Drawing.Point(leftX + labelWidth + textBoxWidth - 55, startY + rowHeight * 2 - 3);
            this.btnLeadLookup.Size = new System.Drawing.Size(50, 22);
            this.btnLeadLookup.Text = "Tìm";
            this.btnLeadLookup.Font = new System.Drawing.Font("Tahoma", 7F);
            this.btnLeadLookup.UseVisualStyleBackColor = true;
            this.btnLeadLookup.FlatStyle = System.Windows.Forms.FlatStyle.System;
            
            // Type of Business *
            this.lblTypeOfBusiness.Location = new System.Drawing.Point(rightX, startY + rowHeight * 2);
            this.lblTypeOfBusiness.Size = new System.Drawing.Size(100, 20);
            this.lblTypeOfBusiness.Text = "Loại hình KD *";
            this.lblTypeOfBusiness.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtTypeOfBusiness.Location = new System.Drawing.Point(rightX + 105, startY + rowHeight * 2 - 2);
            this.txtTypeOfBusiness.Size = new System.Drawing.Size(175, 21);
            this.txtTypeOfBusiness.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTypeOfBusiness.BackColor = System.Drawing.Color.LightPink;
            
            this.btnBusinessLookup.Location = new System.Drawing.Point(rightX + 285, startY + rowHeight * 2 - 3);
            this.btnBusinessLookup.Size = new System.Drawing.Size(50, 22);
            this.btnBusinessLookup.Text = "Tìm";
            this.btnBusinessLookup.Font = new System.Drawing.Font("Tahoma", 7F);
            this.btnBusinessLookup.UseVisualStyleBackColor = true;
            this.btnBusinessLookup.FlatStyle = System.Windows.Forms.FlatStyle.System;
            
            // Address Line 1 *
            this.lblAddressLine1.Location = new System.Drawing.Point(leftX, startY + rowHeight * 3);
            this.lblAddressLine1.Size = new System.Drawing.Size(labelWidth, 20);
            this.lblAddressLine1.Text = "Địa chỉ 1 *";
            this.lblAddressLine1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtAddressLine1.Location = new System.Drawing.Point(leftX + labelWidth, startY + rowHeight * 3 - 2);
            this.txtAddressLine1.Size = new System.Drawing.Size(textBoxWidth, 21);
            this.txtAddressLine1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddressLine1.BackColor = System.Drawing.Color.LightPink;
            
            // SIC Code
            this.lblSICCode.Location = new System.Drawing.Point(rightX, startY + rowHeight * 3);
            this.lblSICCode.Size = new System.Drawing.Size(100, 20);
            this.lblSICCode.Text = "Mã SIC";
            this.lblSICCode.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtSICCode.Location = new System.Drawing.Point(rightX + 105, startY + rowHeight * 3 - 2);
            this.txtSICCode.Size = new System.Drawing.Size(230, 21);
            this.txtSICCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            // Address Line 2
            this.lblAddressLine2.Location = new System.Drawing.Point(leftX, startY + rowHeight * 4);
            this.lblAddressLine2.Size = new System.Drawing.Size(labelWidth, 20);
            this.lblAddressLine2.Text = "Địa chỉ 2";
            this.lblAddressLine2.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtAddressLine2.Location = new System.Drawing.Point(leftX + labelWidth, startY + rowHeight * 4 - 2);
            this.txtAddressLine2.Size = new System.Drawing.Size(textBoxWidth, 21);
            this.txtAddressLine2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            // Organisation Full Description
            this.lblOrgFullDesc.Location = new System.Drawing.Point(rightX, startY + rowHeight * 4);
            this.lblOrgFullDesc.Size = new System.Drawing.Size(100, 35);
            this.lblOrgFullDesc.Text = "Mô tả Tổ chức\r\n(đầy đủ)";
            this.lblOrgFullDesc.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtOrgFullDesc.Location = new System.Drawing.Point(rightX + 105, startY + rowHeight * 4 - 2);
            this.txtOrgFullDesc.Size = new System.Drawing.Size(230, 70);
            this.txtOrgFullDesc.Multiline = true;
            this.txtOrgFullDesc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOrgFullDesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            
            // Address Line 3
            this.lblAddressLine3.Location = new System.Drawing.Point(leftX, startY + rowHeight * 5);
            this.lblAddressLine3.Size = new System.Drawing.Size(labelWidth, 20);
            this.lblAddressLine3.Text = "Địa chỉ 3";
            this.lblAddressLine3.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtAddressLine3.Location = new System.Drawing.Point(leftX + labelWidth, startY + rowHeight * 5 - 2);
            this.txtAddressLine3.Size = new System.Drawing.Size(textBoxWidth, 21);
            this.txtAddressLine3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            // Postcode
            this.lblPostcode.Location = new System.Drawing.Point(leftX, startY + rowHeight * 6);
            this.lblPostcode.Size = new System.Drawing.Size(labelWidth, 20);
            this.lblPostcode.Text = "Mã Bưu điện";
            this.lblPostcode.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtPostcode.Location = new System.Drawing.Point(leftX + labelWidth, startY + rowHeight * 6 - 2);
            this.txtPostcode.Size = new System.Drawing.Size(textBoxWidth - 60, 21);
            this.txtPostcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPostcode.BackColor = System.Drawing.Color.LightPink;
            
            this.btnPostcodeLookup.Location = new System.Drawing.Point(leftX + labelWidth + textBoxWidth - 55, startY + rowHeight * 6 - 3);
            this.btnPostcodeLookup.Size = new System.Drawing.Size(50, 22);
            this.btnPostcodeLookup.Text = "Tìm";
            this.btnPostcodeLookup.Font = new System.Drawing.Font("Tahoma", 7F);
            this.btnPostcodeLookup.UseVisualStyleBackColor = true;
            this.btnPostcodeLookup.FlatStyle = System.Windows.Forms.FlatStyle.System;
            
            // Phone Number *
            this.lblPhoneNumber.Location = new System.Drawing.Point(rightX, startY + rowHeight * 6 + 10);
            this.lblPhoneNumber.Size = new System.Drawing.Size(100, 20);
            this.lblPhoneNumber.Text = "Số Điện thoại *";
            this.lblPhoneNumber.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtPhoneNumber.Location = new System.Drawing.Point(rightX + 105, startY + rowHeight * 6 + 8);
            this.txtPhoneNumber.Size = new System.Drawing.Size(230, 21);
            this.txtPhoneNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPhoneNumber.BackColor = System.Drawing.Color.LightPink;
            
            // City/Town
            this.lblCityTown.Location = new System.Drawing.Point(leftX, startY + rowHeight * 7);
            this.lblCityTown.Size = new System.Drawing.Size(labelWidth, 20);
            this.lblCityTown.Text = "Thành phố/Thị trấn";
            this.lblCityTown.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtCityTown.Location = new System.Drawing.Point(leftX + labelWidth, startY + rowHeight * 7 - 2);
            this.txtCityTown.Size = new System.Drawing.Size(textBoxWidth, 21);
            this.txtCityTown.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            // Fax
            this.lblFax.Location = new System.Drawing.Point(rightX, startY + rowHeight * 7 + 10);
            this.lblFax.Size = new System.Drawing.Size(100, 20);
            this.lblFax.Text = "Fax";
            this.lblFax.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtFax.Location = new System.Drawing.Point(rightX + 105, startY + rowHeight * 7 + 8);
            this.txtFax.Size = new System.Drawing.Size(230, 21);
            this.txtFax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            // County
            this.lblCounty.Location = new System.Drawing.Point(leftX, startY + rowHeight * 8);
            this.lblCounty.Size = new System.Drawing.Size(labelWidth, 20);
            this.lblCounty.Text = "Quận/Huyện";
            this.lblCounty.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtCounty.Location = new System.Drawing.Point(leftX + labelWidth, startY + rowHeight * 8 - 2);
            this.txtCounty.Size = new System.Drawing.Size(textBoxWidth, 21);
            this.txtCounty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            // Email
            this.lblEmail.Location = new System.Drawing.Point(rightX, startY + rowHeight * 8 + 10);
            this.lblEmail.Size = new System.Drawing.Size(100, 20);
            this.lblEmail.Text = "Email";
            this.lblEmail.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtEmail.Location = new System.Drawing.Point(rightX + 105, startY + rowHeight * 8 + 8);
            this.txtEmail.Size = new System.Drawing.Size(230, 21);
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            // Web Address
            this.lblWebAddress.Location = new System.Drawing.Point(rightX, startY + rowHeight * 9 + 10);
            this.lblWebAddress.Size = new System.Drawing.Size(100, 20);
            this.lblWebAddress.Text = "Địa chỉ Web";
            this.lblWebAddress.Font = new System.Drawing.Font("Tahoma", 8.25F);
            
            this.txtWebAddress.Location = new System.Drawing.Point(rightX + 105, startY + rowHeight * 9 + 8);
            this.txtWebAddress.Size = new System.Drawing.Size(230, 21);
            this.txtWebAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            // tabDetails2
            this.tabDetails2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabDetails2.Location = new System.Drawing.Point(4, 22);
            this.tabDetails2.Name = "tabDetails2";
            this.tabDetails2.Padding = new System.Windows.Forms.Padding(3);
            this.tabDetails2.Size = new System.Drawing.Size(752, 394);
            this.tabDetails2.TabIndex = 1;
            this.tabDetails2.Text = "Chi tiết 2";
            
            // tabDetails3
            this.tabDetails3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabDetails3.Location = new System.Drawing.Point(4, 22);
            this.tabDetails3.Name = "tabDetails3";
            this.tabDetails3.Padding = new System.Windows.Forms.Padding(3);
            this.tabDetails3.Size = new System.Drawing.Size(752, 394);
            this.tabDetails3.TabIndex = 2;
            this.tabDetails3.Text = "Chi tiết 3";
            
            // btnSave
            this.btnSave.Location = new System.Drawing.Point(610, 445);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Lưu";
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            
            // btnBack
            this.btnBack.Location = new System.Drawing.Point(695, 445);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Quay lại";
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            
            // FormOrganization
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 500);
            this.Controls.Add(this.grpOrgDetails);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormOrganization";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thông tin Tổ chức";
            this.grpOrgDetails.ResumeLayout(false);
            this.tabControl.ResumeLayout(false);
            this.tabDetails1.ResumeLayout(false);
            this.tabDetails1.PerformLayout();
            this.ResumeLayout(false);
        }
    }
}
