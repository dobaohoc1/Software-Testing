using System;
using System.Windows.Forms;
using OrganizationManagement.Data;
using OrganizationManagement.Data.Models;
using OrganizationManagement.Validators;

namespace OrganizationManagement.Forms
{
    public partial class FormOrganization : Form
    {
        private int savedOrgId = 0;

        public FormOrganization()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Xử lý sự kiện click nút Save
        /// </summary>
        private void btnSave_Click(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ form
            string orgName = txtOrgName.Text.Trim();
            string addressLine1 = txtAddressLine1.Text.Trim();
            string phone = txtPhoneNumber.Text.Trim();
            string email = txtEmail.Text.Trim();

            // Validate OrgName
            if (string.IsNullOrWhiteSpace(orgName))
            {
                MessageBox.Show("Tên Tổ chức không được để trống", "Lỗi nhập liệu", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtOrgName.Focus();
                return;
            }

            if (orgName.Length < 3)
            {
                MessageBox.Show("Tên Tổ chức phải có ít nhất 3 ký tự", "Lỗi nhập liệu", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtOrgName.Focus();
                return;
            }

            // Validate Address Line 1
            if (string.IsNullOrWhiteSpace(addressLine1))
            {
                MessageBox.Show("Địa chỉ 1 không được để trống", "Lỗi nhập liệu", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAddressLine1.Focus();
                return;
            }

            // Validate Phone Number
            if (string.IsNullOrWhiteSpace(phone))
            {
                MessageBox.Show("Số Điện thoại không được để trống", "Lỗi nhập liệu", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPhoneNumber.Focus();
                return;
            }

            // Kiểm tra OrgName đã tồn tại chưa
            if (DatabaseHelper.IsOrgNameExists(orgName))
            {
                MessageBox.Show("Tên Tổ chức đã tồn tại", "Lỗi nhập liệu", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtOrgName.Focus();
                return;
            }

            try
            {
                // Tạo object Organization
                // Gộp các address lines thành một string
                string fullAddress = addressLine1;
                if (!string.IsNullOrWhiteSpace(txtAddressLine2.Text))
                    fullAddress += ", " + txtAddressLine2.Text.Trim();
                if (!string.IsNullOrWhiteSpace(txtAddressLine3.Text))
                    fullAddress += ", " + txtAddressLine3.Text.Trim();
                if (!string.IsNullOrWhiteSpace(txtCityTown.Text))
                    fullAddress += ", " + txtCityTown.Text.Trim();
                if (!string.IsNullOrWhiteSpace(txtCounty.Text))
                    fullAddress += ", " + txtCounty.Text.Trim();
                if (!string.IsNullOrWhiteSpace(txtPostcode.Text))
                    fullAddress += ", " + txtPostcode.Text.Trim();

                var organization = new Organization
                {
                    OrgName = orgName,
                    Address = fullAddress,
                    Phone = phone,
                    Email = string.IsNullOrWhiteSpace(email) ? null : email,
                    CreatedDate = DateTime.Now
                };

                // Lưu vào database
                savedOrgId = DatabaseHelper.SaveOrganization(organization);

                // Hiển thị thông báo thành công
                MessageBox.Show("Lưu thành công!", "Thành công", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi lưu: {ex.Message}", "Lỗi", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Xử lý sự kiện click nút Back
        /// </summary>
        private void btnBack_Click(object sender, EventArgs e)
        {
            // Đóng form hiện tại
            this.Close();
        }
    }
}
